# untitled rng

A free, virtual, collectible RNG Telegram Mini App for the **untitled flood** community,
themed around Brawl Stars characters.

> This is **not** a gambling app. Packs are free and once per day. There are no purchases,
> no paid chances, no betting, and no cash prizes. Tokens are virtual, have no monetary
> value, and only buy cosmetics. Cosmetics never change pack odds.

## Features

| Area | Status |
|---|---|
| Home screen with Jae-yong (pixel mascot, 2-frame breathing at 2 FPS) | Working |
| Free daily pack (server RNG, server cooldown, UTC midnight reset) | Working |
| Rarity odds 52 / 27 / 13 / 6 / 2 % (exact, total 10,000 basis points) | Working, tested exhaustively |
| Collection with mystery state, rarity filters, sorting, detail view | Working |
| Duplicates tracked as quantity, shown in notifications and history | Working |
| History (newest first, persisted) | Working |
| Achievements (6), locked/unlocked, rewards paid once | Working, tested |
| Virtual tokens | Working |
| Cosmetic shop (backgrounds, frames, nameplates, collection themes) + equip | Working |
| Leaderboard (unique / total / legendary) from the database | Working |
| Profile (Telegram name/photo, stats, achievements, equipped cosmetics) | Working |
| Telegram SDK (ready, expand, BackButton, haptics), initData HMAC validation | Implemented; see "Not yet verified" |
| Official character artwork | **Not included**, placeholders only |

## Project structure

```
untitled-rng/
├── package.json
├── .env.example
├── shared/                 Data shared by server and client
│   ├── characters.js       Rarity weights + character roster (edit to expand)
│   ├── achievements.js     Achievement definitions
│   └── cosmetics.js        Cosmetic shop catalogue
├── server/
│   ├── index.js            Entry point (listens on PORT)
│   ├── app.js              Request handler: API + static files
│   ├── config.js           Environment loading
│   ├── db.js               SQLite schema, transactions (node:sqlite)
│   ├── telegram.js         initData HMAC-SHA-256 validation
│   ├── rng.js              Server-side RNG (rarity roll, character pick)
│   ├── packs.js            Daily free pack, cooldown, rewards (one transaction)
│   ├── achievements.js     Stats + one-time achievement awards
│   ├── progress.js         Collection, history, shop, leaderboard, profile queries
│   ├── users.js            Telegram user upsert
│   ├── routes.js           API routes
│   └── http.js             JSON helpers and safe static serving
├── public/
│   ├── index.html          App shell (loads Telegram SDK)
│   ├── css/styles.css      Palette, layout, rarity styles
│   └── js/
│       ├── main.js         Bootstrap + route table
│       ├── router.js       Hash router, BackButton wiring
│       ├── telegram.js     Telegram WebApp integration
│       ├── api.js          The only place that calls the server
│       ├── dom.js          Escaping and formatting helpers
│       ├── components/     ui (toast, tab bar, reveal), sprite (Jae-yong), portrait
│       └── views/          home, collection, history, leaderboard, profile, shop
└── tests/                  node:test suites (RNG, auth, packs/achievements/shop, HTTP)
```

## Run locally

Requirements: **Node.js 22.5 or newer** (uses the built-in `node:sqlite`). There are no
npm dependencies to install.

```bash
cp .env.example .env          # then set BOT_TOKEN
npm test                      # 39 tests
npm start                     # http://localhost:3000
```

To try the UI in a normal browser without Telegram, set `ALLOW_UNSIGNED_DEV_AUTH=true` in
`.env` and open `http://localhost:3000/?dev=12345`. **Never enable this in production.**

## Environment variables

| Name | Required | Purpose |
|---|---|---|
| `BOT_TOKEN` | Yes in production | Verifies Telegram initData. Keep secret. Never ship it to the frontend. |
| `PORT` | No (3000) | HTTP port |
| `DB_PATH` | No | SQLite file path |
| `INIT_DATA_MAX_AGE_SEC` | No (86400) | Max age of a Mini App session |
| `ALLOW_UNSIGNED_DEV_AUTH` | No (false) | Local browser testing only |

## Connect the bot through BotFather

1. Deploy the app to an **HTTPS** URL (Telegram requires HTTPS for Mini Apps), for example
   `https://your-domain.example`.
2. In Telegram, open **@BotFather** → `/newbot` (or select an existing bot).
3. `/newapp` (or `/mybots` → your bot → **Bot Settings → Menu Button → Configure menu button**)
   and set the Web App URL to your HTTPS address.
4. Put the bot token from BotFather into the server's `BOT_TOKEN` environment variable.
5. Open the bot, tap the menu button, and play.

## Security notes

- Identity comes only from Telegram's signed `initData`, checked with the official
  `WebAppData` HMAC-SHA-256 procedure and a timing-safe comparison. Forged, altered or
  expired data gets a 401. The client never supplies a user id or a reward.
- Every reward is computed and written on the server in one SQLite transaction. The daily
  cooldown uses the server's UTC date, so refreshing the app or sending parallel requests
  cannot produce a second free pack.
- Achievements are protected by a `PRIMARY KEY (user_id, achievement_id)`. A second award is
  ignored, so no reward is paid twice.
- Names and usernames are escaped before rendering.
- Static serving refuses paths outside `public/` and `shared/`.

## Game design decisions to review

- **One free pack per UTC day.** The spec says "pack openings must be free" and "one free pack
  per day", so the home button stays disabled until the reset. Extra packs are not sold and
  not granted.
- **Daily token reward:** 5 tokens per free pack. Achievement rewards: 10 to 100 tokens.
- **Rarity** is rolled first with the exact weights, then a character is picked uniformly
  from that rarity's pool. Each character's odds are therefore its tier's odds divided by the
  number of characters in that tier.

## Content that must be checked before launch

- **Rarity tiers per brawler are placeholders.** The Supercell support page and the wiki pages
  I tried did not expose the list of names and tiers. Names are real Brawl Stars brawlers.
  Verify each tier in `shared/characters.js` against the official in-game list.
- **Jae-yong is placed in the Mythic tier as a placeholder.** He is a separate entry from
  Gene.
- **Descriptions are empty** (`description: null`), so the UI shows "Lore entry coming soon."
  Write real text per character.
- **Portraits are original placeholder tiles**, generated from each character id. Replace
  them with licensed or drawn artwork when available.
- Brawl Stars, Supercell and Telegram trademarks belong to their owners. Check fan-content
  terms before public launch.

## Not yet verified

- **Live Telegram.** The Telegram SDK and the real `initData` path were not tested inside the
  Telegram client, since no live bot or public HTTPS URL is available here. The HMAC check is
  tested against values built with the same algorithm, including tampered and expired
  payloads.
- **Native BackButton and haptics** were not exercised, because the SDK does not load in the
  headless browser. The code paths are guarded so they do nothing when the SDK is absent.
- **Theme colors.** The app uses its fixed palette and ignores Telegram's theme parameters.
- **Browser coverage** was checked in headless Chrome at 390 px width only. Safari on iPhone
  was not tested.

## Deployment requirements

- A host with Node.js 22.5 or newer and persistent disk for the SQLite file (or migrate to
  PostgreSQL if you need several instances).
- HTTPS termination in front of the server (a reverse proxy or a platform's TLS).
- `BOT_TOKEN` stored in the host's secret manager.
