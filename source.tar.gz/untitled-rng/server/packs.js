import { transaction } from './db.js';
import { rollCharacter } from './rng.js';
import { evaluateAchievements } from './achievements.js';
import { CHARACTERS_BY_ID } from '../shared/characters.js';

export const DAILY_PACK_TOKEN_REWARD = 5;

export class CooldownError extends Error {
  constructor(nextFreeAt) {
    super('The free pack for today has already been opened');
    this.name = 'CooldownError';
    this.status = 409;
    this.code = 'COOLDOWN';
    this.nextFreeAt = nextFreeAt;
  }
}

export class NotFoundError extends Error {
  constructor(message = 'Not found') {
    super(message);
    this.name = 'NotFoundError';
    this.status = 404;
  }
}

// The free-pack day boundary is UTC midnight, so every player shares one reset.
export function utcDay(nowMs) {
  return new Date(nowMs).toISOString().slice(0, 10);
}

export function nextUtcMidnightIso(nowMs) {
  const d = new Date(nowMs);
  return new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate() + 1)).toISOString();
}

export function getFreeOpeningStatus(db, userId, nowMs = Date.now()) {
  const user = db.prepare('SELECT last_free_day FROM users WHERE id = ?').get(userId);
  if (!user) throw new NotFoundError('User not found');
  const available = user.last_free_day !== utcDay(nowMs);
  return {
    available,
    nextFreeAt: available ? null : nextUtcMidnightIso(nowMs),
    lastFreeDay: user.last_free_day,
  };
}

// Opens today's free pack. The entire operation (cooldown check, RNG, inventory,
// history, tokens, achievements) runs in ONE transaction. The cooldown is checked
// against the server clock inside that transaction, so refreshing the client or
// sending parallel requests cannot produce a second pack.
export function openDailyPack(db, userId, { nowMs = Date.now(), randomInt, source = 'daily' } = {}) {
  return transaction(db, () => {
    const user = db.prepare('SELECT id, last_free_day FROM users WHERE id = ?').get(userId);
    if (!user) throw new NotFoundError('User not found');

    const today = utcDay(nowMs);
    if (user.last_free_day === today) {
      throw new CooldownError(nextUtcMidnightIso(nowMs));
    }

    const character = rollCharacter(randomInt);
    const nowIso = new Date(nowMs).toISOString();

    const existing = db.prepare(
      'SELECT quantity FROM inventory WHERE user_id = ? AND character_id = ?',
    ).get(userId, character.id);
    const isNew = !existing;

    if (isNew) {
      db.prepare(
        'INSERT INTO inventory (user_id, character_id, quantity, first_obtained_at) VALUES (?, ?, 1, ?)',
      ).run(userId, character.id, nowIso);
    } else {
      db.prepare(
        'UPDATE inventory SET quantity = quantity + 1 WHERE user_id = ? AND character_id = ?',
      ).run(userId, character.id);
    }

    db.prepare(`
      INSERT INTO history (user_id, character_id, rarity, is_new, source, created_at)
      VALUES (?, ?, ?, ?, ?, ?)
    `).run(userId, character.id, character.rarity, isNew ? 1 : 0, source, nowIso);

    db.prepare(
      'UPDATE users SET last_free_day = ?, tokens = tokens + ?, updated_at = ? WHERE id = ?',
    ).run(today, DAILY_PACK_TOKEN_REWARD, nowIso, userId);

    const achievements = evaluateAchievements(db, userId, nowIso);

    const quantity = db.prepare(
      'SELECT quantity FROM inventory WHERE user_id = ? AND character_id = ?',
    ).get(userId, character.id).quantity;
    const tokens = db.prepare('SELECT tokens FROM users WHERE id = ?').get(userId).tokens;

    return {
      character: publicCharacter(character),
      quantity,
      isNew,
      isDuplicate: !isNew,
      tokensEarned: DAILY_PACK_TOKEN_REWARD + achievements.reduce((sum, a) => sum + a.reward, 0),
      tokens,
      achievementsUnlocked: achievements.map((a) => ({ id: a.id, name: a.name, reward: a.reward, icon: a.icon })),
      nextFreeAt: nextUtcMidnightIso(nowMs),
      openedAt: nowIso,
    };
  });
}

export function publicCharacter(character) {
  return {
    id: character.id,
    name: character.name,
    rarity: character.rarity,
    mascot: character.mascot,
  };
}

export function characterById(id) {
  return CHARACTERS_BY_ID[id] ?? null;
}
