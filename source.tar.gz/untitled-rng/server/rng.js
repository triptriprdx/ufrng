import crypto from 'node:crypto';
import { RARITIES, CHARACTERS, CHARACTERS_BY_RARITY, TOTAL_WEIGHT } from '../shared/characters.js';

// All randomness comes from `randomInt`, which defaults to crypto.randomInt.
// Tests inject a fake one. The client never supplies or influences these values.

export function rollRarity(randomInt = crypto.randomInt) {
  const roll = randomInt(TOTAL_WEIGHT); // integer in [0, 10000)
  let threshold = 0;
  for (const rarity of RARITIES) {
    threshold += rarity.weight;
    if (roll < threshold) return rarity.id;
  }
  throw new Error('Rarity weights do not cover the full range');
}

export function rollCharacter(randomInt = crypto.randomInt) {
  const rarityId = rollRarity(randomInt);
  const pool = CHARACTERS_BY_RARITY[rarityId];
  return pool[randomInt(pool.length)];
}

// Exact probability of each rarity in basis points, for display and tests.
export function rarityOdds() {
  return RARITIES.map((r) => ({ id: r.id, percent: r.weight / 100 }));
}

export { CHARACTERS };
