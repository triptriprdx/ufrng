import crypto from 'node:crypto';

export class AuthError extends Error {
  constructor(message) {
    super(message);
    this.name = 'AuthError';
    this.status = 401;
  }
}

// Validates Telegram Mini App initData using the official HMAC-SHA-256 procedure:
//   secret_key     = HMAC_SHA256(key = "WebAppData", message = bot_token)
//   data_check     = all fields except "hash", sorted by key, "key=value" joined by "\n"
//   expected_hash  = hex(HMAC_SHA256(key = secret_key, message = data_check))
// https://core.telegram.org/bots/webapps#validating-data-received-via-the-mini-app
export function validateInitData(initData, botToken, { maxAgeSec = 86400, nowMs = Date.now() } = {}) {
  if (!botToken) throw new AuthError('Server is not configured with a bot token');
  if (typeof initData !== 'string' || initData.length === 0) throw new AuthError('Missing initData');

  const params = new URLSearchParams(initData);
  const receivedHash = params.get('hash');
  if (!receivedHash) throw new AuthError('initData has no hash');
  params.delete('hash');

  const dataCheckString = [...params.entries()]
    .sort(([a], [b]) => (a < b ? -1 : a > b ? 1 : 0))
    .map(([key, value]) => `${key}=${value}`)
    .join('\n');

  const secretKey = crypto.createHmac('sha256', 'WebAppData').update(botToken).digest();
  const expected = crypto.createHmac('sha256', secretKey).update(dataCheckString).digest();
  const received = Buffer.from(receivedHash, 'hex');
  if (received.length !== expected.length || !crypto.timingSafeEqual(received, expected)) {
    throw new AuthError('initData signature is invalid');
  }

  const authDate = Number(params.get('auth_date'));
  if (!Number.isFinite(authDate) || authDate <= 0) throw new AuthError('initData has no valid auth_date');
  const ageSec = nowMs / 1000 - authDate;
  if (ageSec > maxAgeSec) throw new AuthError('initData has expired; reopen the Mini App');
  if (ageSec < -60) throw new AuthError('initData auth_date is in the future');

  let user;
  try {
    user = JSON.parse(params.get('user') ?? 'null');
  } catch {
    throw new AuthError('initData user is malformed');
  }
  if (!user || !Number.isSafeInteger(user.id)) throw new AuthError('initData has no user');

  return {
    id: user.id,
    username: typeof user.username === 'string' ? user.username : null,
    firstName: typeof user.first_name === 'string' ? user.first_name : '',
    lastName: typeof user.last_name === 'string' ? user.last_name : '',
    photoUrl: typeof user.photo_url === 'string' ? user.photo_url : null,
  };
}

// Reads the Authorization header. Accepts `tma <initData>` in production.
// `dev <telegramId>` is accepted only when ALLOW_UNSIGNED_DEV_AUTH=true.
export function authenticateRequest(authorizationHeader, config) {
  const header = authorizationHeader ?? '';
  if (header.startsWith('tma ')) {
    return validateInitData(header.slice(4), config.botToken, { maxAgeSec: config.initDataMaxAgeSec });
  }
  if (header.startsWith('dev ') && config.allowUnsignedDevAuth) {
    const id = Number(header.slice(4));
    if (!Number.isSafeInteger(id) || id <= 0) throw new AuthError('Invalid dev user id');
    return { id, username: `dev${id}`, firstName: `Dev ${id}`, lastName: '', photoUrl: null };
  }
  throw new AuthError('Authentication required');
}
