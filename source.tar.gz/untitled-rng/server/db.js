import fs from 'node:fs';
import path from 'node:path';
import { DatabaseSync } from 'node:sqlite';

const SCHEMA = `
CREATE TABLE IF NOT EXISTS users (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  telegram_id   INTEGER NOT NULL UNIQUE,
  username      TEXT,
  display_name  TEXT NOT NULL,
  photo_url     TEXT,
  tokens        INTEGER NOT NULL DEFAULT 0 CHECK (tokens >= 0),
  last_free_day TEXT,               -- UTC date (YYYY-MM-DD) of the last free pack
  created_at    TEXT NOT NULL,
  updated_at    TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS inventory (
  user_id            INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  character_id       TEXT NOT NULL,
  quantity           INTEGER NOT NULL CHECK (quantity >= 1),
  first_obtained_at  TEXT NOT NULL,
  PRIMARY KEY (user_id, character_id)
);

CREATE TABLE IF NOT EXISTS history (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id       INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  character_id  TEXT NOT NULL,
  rarity        TEXT NOT NULL,
  is_new        INTEGER NOT NULL CHECK (is_new IN (0, 1)),
  source        TEXT NOT NULL DEFAULT 'daily',
  created_at    TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_history_user ON history(user_id, id);

CREATE TABLE IF NOT EXISTS achievements_unlocked (
  user_id         INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  achievement_id  TEXT NOT NULL,
  unlocked_at     TEXT NOT NULL,
  PRIMARY KEY (user_id, achievement_id)   -- a row can exist only once: no double rewards
);

CREATE TABLE IF NOT EXISTS cosmetics_owned (
  user_id   INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  item_id   TEXT NOT NULL,
  bought_at TEXT NOT NULL,
  PRIMARY KEY (user_id, item_id)
);

CREATE TABLE IF NOT EXISTS cosmetics_equipped (
  user_id  INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  slot     TEXT NOT NULL,
  item_id  TEXT NOT NULL,
  PRIMARY KEY (user_id, slot)
);
`;

export function openDatabase(file) {
  if (file !== ':memory:') fs.mkdirSync(path.dirname(file), { recursive: true });
  const db = new DatabaseSync(file);
  db.exec('PRAGMA foreign_keys = ON;');
  if (file !== ':memory:') db.exec('PRAGMA journal_mode = WAL;');
  db.exec(SCHEMA);
  return db;
}

// Runs fn inside a write transaction. Node's sqlite driver is synchronous, so
// BEGIN IMMEDIATE plus synchronous execution means no two reward operations
// can interleave.
export function transaction(db, fn) {
  db.exec('BEGIN IMMEDIATE');
  try {
    const result = fn();
    db.exec('COMMIT');
    return result;
  } catch (error) {
    db.exec('ROLLBACK');
    throw error;
  }
}
