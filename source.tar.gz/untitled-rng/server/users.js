// Creates or refreshes a user from a validated Telegram identity.
// Only call this with data that came out of validateInitData().
export function upsertTelegramUser(db, identity, now = new Date()) {
  const timestamp = now.toISOString();
  const displayName = [identity.firstName, identity.lastName].filter(Boolean).join(' ').trim()
    || identity.username
    || `Player ${identity.id}`;

  db.prepare(`
    INSERT INTO users (telegram_id, username, display_name, photo_url, created_at, updated_at)
    VALUES (?, ?, ?, ?, ?, ?)
    ON CONFLICT(telegram_id) DO UPDATE SET
      username = excluded.username,
      display_name = excluded.display_name,
      photo_url = excluded.photo_url,
      updated_at = excluded.updated_at
  `).run(identity.id, identity.username, displayName.slice(0, 64), identity.photoUrl, timestamp, timestamp);

  return db.prepare('SELECT * FROM users WHERE telegram_id = ?').get(identity.id);
}

export function getUserById(db, userId) {
  return db.prepare('SELECT * FROM users WHERE id = ?').get(userId) ?? null;
}
