import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

export const ROOT_DIR = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');

// Loads a .env file if present. Real environment variables always win.
function loadEnvFile(file) {
  if (!fs.existsSync(file)) return;
  for (const line of fs.readFileSync(file, 'utf8').split(/\r?\n/)) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith('#')) continue;
    const eq = trimmed.indexOf('=');
    if (eq === -1) continue;
    const key = trimmed.slice(0, eq).trim();
    let value = trimmed.slice(eq + 1).trim();
    if ((value.startsWith('"') && value.endsWith('"')) || (value.startsWith("'") && value.endsWith("'"))) {
      value = value.slice(1, -1);
    }
    if (process.env[key] === undefined) process.env[key] = value;
  }
}

export function loadConfig(env = process.env) {
  loadEnvFile(path.join(ROOT_DIR, '.env'));
  return Object.freeze({
    botToken: env.BOT_TOKEN ?? '',
    port: Number(env.PORT ?? 3000),
    dbPath: path.resolve(ROOT_DIR, env.DB_PATH ?? 'data/untitled-rng.sqlite'),
    initDataMaxAgeSec: Number(env.INIT_DATA_MAX_AGE_SEC ?? 86400),
    // Local development only. Lets you open the app in a normal browser with
    // `?dev=<telegramId>`. Must stay false in production.
    allowUnsignedDevAuth: env.ALLOW_UNSIGNED_DEV_AUTH === 'true',
    publicDir: path.join(ROOT_DIR, 'public'),
    sharedDir: path.join(ROOT_DIR, 'shared'),
  });
}
