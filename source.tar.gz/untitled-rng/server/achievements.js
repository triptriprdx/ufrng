import { ACHIEVEMENTS } from '../shared/achievements.js';
import { CHARACTERS } from '../shared/characters.js';

// Computes every stat an achievement can depend on. Everything is derived from
// the database, so the client cannot claim progress it does not have.
export function computeStats(db, userId) {
  const openings = db.prepare('SELECT COUNT(*) AS n FROM history WHERE user_id = ?').get(userId).n;
  const unique = db.prepare('SELECT COUNT(*) AS n FROM inventory WHERE user_id = ? AND quantity >= 1').get(userId).n;
  const legendary = db.prepare("SELECT COUNT(*) AS n FROM history WHERE user_id = ? AND rarity = 'legendary'").get(userId).n;
  return {
    openings,
    unique,
    legendary,
    full_house: unique >= CHARACTERS.length ? 1 : 0,
  };
}

// Must run inside a transaction. Returns the achievements newly unlocked in this call.
// The PRIMARY KEY on (user_id, achievement_id) makes a second award impossible: the
// INSERT is ignored, changes === 0, and the reward is skipped.
export function evaluateAchievements(db, userId, nowIso) {
  const stats = computeStats(db, userId);
  const insert = db.prepare(
    'INSERT OR IGNORE INTO achievements_unlocked (user_id, achievement_id, unlocked_at) VALUES (?, ?, ?)',
  );
  const grantTokens = db.prepare('UPDATE users SET tokens = tokens + ?, updated_at = ? WHERE id = ?');

  const unlocked = [];
  for (const achievement of ACHIEVEMENTS) {
    if (stats[achievement.metric] < achievement.threshold) continue;
    const result = insert.run(userId, achievement.id, nowIso);
    if (result.changes === 1) {
      grantTokens.run(achievement.reward, nowIso, userId);
      unlocked.push(achievement);
    }
  }
  return unlocked;
}

export function listAchievementsForUser(db, userId) {
  const rows = db.prepare(
    'SELECT achievement_id, unlocked_at FROM achievements_unlocked WHERE user_id = ?',
  ).all(userId);
  const unlockedAt = new Map(rows.map((r) => [r.achievement_id, r.unlocked_at]));
  return ACHIEVEMENTS.map((a) => ({
    id: a.id,
    name: a.name,
    description: a.description,
    icon: a.icon,
    reward: a.reward,
    unlocked: unlockedAt.has(a.id),
    unlockedAt: unlockedAt.get(a.id) ?? null,
  }));
}
