import crypto from 'node:crypto';
import { handleApi, errorResponse } from './routes.js';
import { serveStatic, sendJson } from './http.js';

// Builds the request handler. Kept separate from listen() so tests can run it
// against a temporary database and a random port.
export function createRequestHandler({ db, config, now = () => Date.now(), randomInt = crypto.randomInt, log = console }) {
  const ctx = { db, config, now, randomInt };

  return async function handleRequest(req, res) {
    try {
      const url = new URL(req.url ?? '/', 'http://localhost');

      if (url.pathname.startsWith('/api/')) {
        const handled = await handleApi(req, res, url, ctx);
        if (handled) return;
      }

      if (url.pathname === '/shared' || url.pathname.startsWith('/shared/')) {
        serveStatic(req, res, url.pathname, config.sharedDir, '/shared');
        return;
      }

      serveStatic(req, res, url.pathname, config.publicDir);
    } catch (error) {
      if (!(error?.status)) log.error('[untitled-rng] unexpected error:', error);
      const { status, body } = errorResponse(error);
      if (!res.headersSent) sendJson(res, status, body);
      else res.end();
    }
  };
}
