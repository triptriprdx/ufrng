import { authenticateRequest, AuthError } from './telegram.js';
import { upsertTelegramUser } from './users.js';
import { HttpError, readJsonBody, sendJson } from './http.js';
import { openDailyPack, getFreeOpeningStatus, CooldownError, NotFoundError } from './packs.js';
import { getCollection, getHistory, getLeaderboard, getShop, buyCosmetic, equipCosmetic, getProfile, getEquipped, LEADERBOARD_METRIC_KEYS, ConflictError } from './progress.js';
import { CHARACTERS, RARITIES } from '../shared/characters.js';

// Resolves the authenticated Telegram identity and its database user row.
// Identity always comes from the validated initData, never from the request body.
function requireUser(req, ctx) {
  let identity;
  try {
    identity = authenticateRequest(req.headers.authorization, ctx.config);
  } catch (error) {
    if (error instanceof AuthError) throw new HttpError(401, error.message);
    throw error;
  }
  return upsertTelegramUser(ctx.db, identity);
}

function bootstrapPayload(db, user, nowMs) {
  const profile = getProfile(db, user.id);
  const free = getFreeOpeningStatus(db, user.id, nowMs);
  const collection = getCollection(db, user.id);
  return {
    user: profile.user,
    freeOpening: free,
    progress: collection.progress,
    stats: profile.stats,
    recentHistory: getHistory(db, user.id, 5),
    achievementsUnlocked: profile.achievements.filter((a) => a.unlocked).length,
    achievementsTotal: profile.achievements.length,
    rarities: RARITIES.map((r) => ({ id: r.id, name: r.name, percent: r.weight / 100 })),
  };
}

const routes = {
  'GET /api/health': () => ({ status: 200, body: { ok: true } }),

  'GET /api/home': (req, ctx) => {
    const user = requireUser(req, ctx);
    return { status: 200, body: bootstrapPayload(ctx.db, user, ctx.now()) };
  },

  'POST /api/packs/open': (req, ctx) => {
    const user = requireUser(req, ctx);
    try {
      const result = openDailyPack(ctx.db, user.id, { nowMs: ctx.now(), randomInt: ctx.randomInt });
      return { status: 201, body: result };
    } catch (error) {
      if (error instanceof CooldownError) {
        return {
          status: 409,
          body: { error: error.message, code: error.code, nextFreeAt: error.nextFreeAt },
        };
      }
      if (error instanceof NotFoundError) throw new HttpError(404, error.message);
      throw error;
    }
  },

  'GET /api/collection': (req, ctx) => {
    const user = requireUser(req, ctx);
    return { status: 200, body: getCollection(ctx.db, user.id) };
  },

  'GET /api/history': (req, ctx) => {
    const user = requireUser(req, ctx);
    const limit = clampInt(ctx.query.get('limit'), 1, 200, 100);
    return { status: 200, body: { items: getHistory(ctx.db, user.id, limit) } };
  },

  'GET /api/leaderboard': (req, ctx) => {
    requireUser(req, ctx);
    const metric = ctx.query.get('metric') ?? 'unique';
    if (!LEADERBOARD_METRIC_KEYS.includes(metric)) throw new HttpError(400, 'Unknown metric');
    return { status: 200, body: { metric, entries: getLeaderboard(ctx.db, metric, 50) } };
  },

  'GET /api/profile': (req, ctx) => {
    const user = requireUser(req, ctx);
    return { status: 200, body: getProfile(ctx.db, user.id) };
  },

  'GET /api/shop': (req, ctx) => {
    const user = requireUser(req, ctx);
    return { status: 200, body: getShop(ctx.db, user.id) };
  },

  'POST /api/shop/buy': async (req, ctx) => {
    const user = requireUser(req, ctx);
    const body = await readJsonBody(req);
    try {
      return { status: 200, body: buyCosmetic(ctx.db, user.id, String(body.itemId ?? ''), new Date(ctx.now()).toISOString()) };
    } catch (error) {
      if (error instanceof ConflictError) throw new HttpError(409, error.message);
      if (error instanceof NotFoundError) throw new HttpError(404, error.message);
      throw error;
    }
  },

  'POST /api/shop/equip': async (req, ctx) => {
    const user = requireUser(req, ctx);
    const body = await readJsonBody(req);
    try {
      equipCosmetic(ctx.db, user.id, String(body.itemId ?? ''));
      return { status: 200, body: { equipped: getEquipped(ctx.db, user.id) } };
    } catch (error) {
      if (error instanceof ConflictError) throw new HttpError(409, error.message);
      if (error instanceof NotFoundError) throw new HttpError(404, error.message);
      throw error;
    }
  },

  'GET /api/catalog': () => ({
    status: 200,
    body: {
      rarities: RARITIES,
      characterCount: CHARACTERS.length,
    },
  }),
};

function clampInt(raw, min, max, fallback) {
  const n = Number.parseInt(raw ?? '', 10);
  if (!Number.isFinite(n)) return fallback;
  return Math.min(max, Math.max(min, n));
}

// Returns true if the request was an API route (handled or rejected), false otherwise.
export async function handleApi(req, res, url, ctx) {
  const key = `${req.method} ${url.pathname}`;
  const handler = routes[key];
  if (!handler) {
    if (url.pathname.startsWith('/api/')) {
      sendJson(res, 404, { error: 'Unknown API route' });
      return true;
    }
    return false;
  }
  const routeCtx = { ...ctx, query: url.searchParams };
  const result = await handler(req, routeCtx);
  sendJson(res, result.status, result.body);
  return true;
}

// Maps any thrown error to an HTTP response. Errors that carry a 4xx status are
// safe to show; anything else becomes a generic 500 so internals never leak.
export function errorResponse(error) {
  const status = error?.status;
  if (typeof status === 'number' && status >= 400 && status < 500) {
    return { status, body: { error: error.message, ...(error.extra ?? {}) } };
  }
  return { status: 500, body: { error: 'Internal server error' } };
}
