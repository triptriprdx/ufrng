import { CHARACTERS } from '../shared/characters.js';
import { COSMETICS, COSMETICS_BY_ID, COSMETIC_SLOTS } from '../shared/cosmetics.js';
import { transaction } from './db.js';
import { listAchievementsForUser, computeStats } from './achievements.js';
import { NotFoundError } from './packs.js';

// Every read below is derived from the database. Nothing here trusts the client.

export function getCollection(db, userId) {
  const owned = new Map(
    db.prepare('SELECT character_id, quantity, first_obtained_at FROM inventory WHERE user_id = ?')
      .all(userId)
      .map((r) => [r.character_id, r]),
  );
  const characters = CHARACTERS.map((c) => {
    const row = owned.get(c.id);
    return {
      id: c.id,
      name: c.name,
      rarity: c.rarity,
      mascot: c.mascot,
      description: c.description,
      collectionOrder: c.collectionOrder,
      unlocked: Boolean(row),
      quantity: row ? row.quantity : 0,
      firstObtainedAt: row ? row.first_obtained_at : null,
    };
  });
  const unique = characters.filter((c) => c.unlocked).length;
  return {
    characters,
    progress: { unique, total: CHARACTERS.length, percent: Math.round((unique / CHARACTERS.length) * 100) },
  };
}

export function getHistory(db, userId, limit = 100) {
  return db.prepare(`
    SELECT id, character_id, rarity, is_new, created_at
    FROM history WHERE user_id = ? ORDER BY id DESC LIMIT ?
  `).all(userId, limit).map((r) => ({
    id: r.id,
    characterId: r.character_id,
    rarity: r.rarity,
    isNew: r.is_new === 1,
    isDuplicate: r.is_new === 0,
    createdAt: r.created_at,
  }));
}

// Metric expressions are fixed SQL strings. The client picks a key, never the SQL.
const LEADERBOARD_METRICS = {
  unique: `(SELECT COUNT(*) FROM inventory i WHERE i.user_id = u.id AND i.quantity >= 1)`,
  total: `(SELECT COUNT(*) FROM history h WHERE h.user_id = u.id)`,
  legendary: `(SELECT COUNT(*) FROM history h WHERE h.user_id = u.id AND h.rarity = 'legendary')`,
};

export const LEADERBOARD_METRIC_KEYS = Object.freeze(Object.keys(LEADERBOARD_METRICS));

export function getLeaderboard(db, metric = 'unique', limit = 50) {
  const expression = LEADERBOARD_METRICS[metric];
  if (!expression) throw new RangeError(`Unknown leaderboard metric: ${metric}`);
  const rows = db.prepare(`
    SELECT * FROM (
      SELECT u.id, u.username, u.display_name, u.photo_url, ${expression} AS value
      FROM users u
    )
    WHERE value > 0
    ORDER BY value DESC, id ASC
    LIMIT ?
  `).all(limit);
  return rows.map((r, index) => ({
    rank: index + 1,
    userId: r.id,
    displayName: r.display_name,
    username: r.username,
    photoUrl: r.photo_url,
    value: r.value,
  }));
}

export function getShop(db, userId) {
  const owned = new Set(
    db.prepare('SELECT item_id FROM cosmetics_owned WHERE user_id = ?').all(userId).map((r) => r.item_id),
  );
  const equipped = getEquipped(db, userId);
  const user = db.prepare('SELECT tokens FROM users WHERE id = ?').get(userId);
  return {
    tokens: user.tokens,
    slots: COSMETIC_SLOTS,
    items: COSMETICS.map((item) => ({
      ...item,
      owned: owned.has(item.id),
      equipped: equipped[item.slot] === item.id,
    })),
  };
}

export function getEquipped(db, userId) {
  const equipped = {};
  for (const row of db.prepare('SELECT slot, item_id FROM cosmetics_equipped WHERE user_id = ?').all(userId)) {
    equipped[row.slot] = row.item_id;
  }
  return equipped;
}

export function buyCosmetic(db, userId, itemId, nowIso = new Date().toISOString()) {
  const item = COSMETICS_BY_ID[itemId];
  if (!item) throw new NotFoundError('Unknown cosmetic');
  return transaction(db, () => {
    const already = db.prepare('SELECT 1 FROM cosmetics_owned WHERE user_id = ? AND item_id = ?').get(userId, itemId);
    if (already) throw new ConflictError('You already own this cosmetic');
    const user = db.prepare('SELECT tokens FROM users WHERE id = ?').get(userId);
    if (!user) throw new NotFoundError('User not found');
    if (user.tokens < item.cost) throw new ConflictError('Not enough tokens');
    db.prepare('UPDATE users SET tokens = tokens - ?, updated_at = ? WHERE id = ?').run(item.cost, nowIso, userId);
    db.prepare('INSERT INTO cosmetics_owned (user_id, item_id, bought_at) VALUES (?, ?, ?)').run(userId, itemId, nowIso);
    return { tokens: user.tokens - item.cost };
  });
}

export function equipCosmetic(db, userId, itemId) {
  const item = COSMETICS_BY_ID[itemId];
  if (!item) throw new NotFoundError('Unknown cosmetic');
  return transaction(db, () => {
    const owned = db.prepare('SELECT 1 FROM cosmetics_owned WHERE user_id = ? AND item_id = ?').get(userId, itemId);
    if (!owned) throw new ConflictError('You do not own this cosmetic yet');
    db.prepare(`
      INSERT INTO cosmetics_equipped (user_id, slot, item_id) VALUES (?, ?, ?)
      ON CONFLICT(user_id, slot) DO UPDATE SET item_id = excluded.item_id
    `).run(userId, item.slot, itemId);
    return { slot: item.slot, itemId };
  });
}

export function getProfile(db, userId) {
  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(userId);
  if (!user) throw new NotFoundError('User not found');
  const stats = computeStats(db, userId);
  const equipped = getEquipped(db, userId);
  const ownedCosmetics = db.prepare('SELECT item_id FROM cosmetics_owned WHERE user_id = ?').all(userId)
    .map((r) => COSMETICS_BY_ID[r.item_id])
    .filter(Boolean);

  return {
    user: {
      id: user.id,
      displayName: user.display_name,
      username: user.username,
      photoUrl: user.photo_url,
      tokens: user.tokens,
    },
    stats: {
      totalDiscoveries: stats.openings,
      uniqueCharacters: stats.unique,
      legendaryCharacters: stats.legendary,
      collectionSize: CHARACTERS.length,
    },
    achievements: listAchievementsForUser(db, userId),
    cosmetics: {
      owned: ownedCosmetics,
      equipped,
    },
  };
}

export class ConflictError extends Error {
  constructor(message) {
    super(message);
    this.name = 'ConflictError';
    this.status = 409;
  }
}
