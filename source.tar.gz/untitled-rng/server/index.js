import http from 'node:http';
import { loadConfig } from './config.js';
import { openDatabase } from './db.js';
import { createRequestHandler } from './app.js';

const config = loadConfig();

if (!config.botToken) {
  console.warn('[untitled-rng] BOT_TOKEN is not set. Every API call will fail authentication.');
}
if (config.allowUnsignedDevAuth) {
  console.warn('[untitled-rng] ALLOW_UNSIGNED_DEV_AUTH=true: unsigned dev logins are accepted. Do not use in production.');
}

const db = openDatabase(config.dbPath);
const server = http.createServer(createRequestHandler({ db, config }));

server.listen(config.port, () => {
  console.log(`untitled rng listening on http://localhost:${config.port}`);
  console.log(`database: ${config.dbPath}`);
});

function shutdown() {
  server.close(() => {
    db.close();
    process.exit(0);
  });
}
process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);
