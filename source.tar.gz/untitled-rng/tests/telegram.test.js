import { test } from 'node:test';
import assert from 'node:assert/strict';
import { validateInitData, authenticateRequest, AuthError } from '../server/telegram.js';
import { buildInitData } from './helpers.js';

const BOT_TOKEN = '123456:TEST_TOKEN_FOR_UNIT_TESTS';
const USER = { id: 42, first_name: 'Ada', last_name: 'L', username: 'ada_l', photo_url: null };

test('accepts initData signed with the correct bot token', () => {
  const initData = buildInitData({ botToken: BOT_TOKEN, user: USER });
  const identity = validateInitData(initData, BOT_TOKEN);
  assert.equal(identity.id, 42);
  assert.equal(identity.username, 'ada_l');
});

test('rejects initData signed with a different bot token', () => {
  const initData = buildInitData({ botToken: 'other:token', user: USER });
  assert.throws(() => validateInitData(initData, BOT_TOKEN), AuthError);
});

test('rejects initData where the user id was tampered with after signing', () => {
  const initData = buildInitData({ botToken: BOT_TOKEN, user: USER });
  const tampered = initData.replace(encodeURIComponent(JSON.stringify(USER)), encodeURIComponent(JSON.stringify({ ...USER, id: 999 })));
  assert.notEqual(tampered, initData, 'test setup: tampering must change the string');
  assert.throws(() => validateInitData(tampered, BOT_TOKEN), /signature is invalid/);
});

test('rejects a forged hash', () => {
  const initData = buildInitData({ botToken: BOT_TOKEN, user: USER });
  const forged = initData.replace(/hash=[0-9a-f]+/, 'hash=' + '0'.repeat(64));
  assert.throws(() => validateInitData(forged, BOT_TOKEN), AuthError);
});

test('rejects initData without a hash, or with a non-hex hash', () => {
  const initData = buildInitData({ botToken: BOT_TOKEN, user: USER });
  assert.throws(() => validateInitData(initData.replace(/&hash=.*/, ''), BOT_TOKEN), /no hash/);
  assert.throws(() => validateInitData(initData.replace(/hash=[0-9a-f]+/, 'hash=zz'), BOT_TOKEN), AuthError);
});

test('rejects expired initData', () => {
  const oldAuth = Math.floor(Date.now() / 1000) - 3 * 86400;
  const initData = buildInitData({ botToken: BOT_TOKEN, user: USER, authDate: oldAuth });
  assert.throws(() => validateInitData(initData, BOT_TOKEN, { maxAgeSec: 86400 }), /expired/);
});

test('rejects when the server has no bot token configured', () => {
  const initData = buildInitData({ botToken: BOT_TOKEN, user: USER });
  assert.throws(() => validateInitData(initData, ''), /not configured/);
});

test('authenticateRequest refuses missing and unsigned headers by default', () => {
  const config = { botToken: BOT_TOKEN, allowUnsignedDevAuth: false, initDataMaxAgeSec: 86400 };
  assert.throws(() => authenticateRequest(undefined, config), /Authentication required/);
  assert.throws(() => authenticateRequest('dev 42', config), /Authentication required/);
  assert.throws(() => authenticateRequest('tma garbage', config), AuthError);
});

test('dev auth works only when explicitly enabled', () => {
  const config = { botToken: BOT_TOKEN, allowUnsignedDevAuth: true, initDataMaxAgeSec: 86400 };
  assert.equal(authenticateRequest('dev 7', config).id, 7);
});
