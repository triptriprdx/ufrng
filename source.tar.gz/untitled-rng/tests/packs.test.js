import { test } from 'node:test';
import assert from 'node:assert/strict';
import { openDatabase } from '../server/db.js';
import { upsertTelegramUser } from '../server/users.js';
import { openDailyPack, CooldownError, utcDay } from '../server/packs.js';
import { getCollection, getHistory, getLeaderboard, getShop, buyCosmetic, equipCosmetic, ConflictError } from '../server/progress.js';
import { CHARACTERS_BY_RARITY, CHARACTERS } from '../shared/characters.js';

const DAY = 86_400_000;
const T0 = Date.UTC(2026, 10, 10, 12, 0, 0); // 2026-11-10 12:00 UTC

// Random source that always returns the given value for the rarity roll and index 0.
// rarityRoll is in [0, 10000); the character index is always the first in the pool.
function fixedRoll(rarityRoll) {
  return (max) => (max === 10000 ? rarityRoll : 0);
}

function newUser(db, telegramId = 1, name = 'Tester') {
  return upsertTelegramUser(db, { id: telegramId, firstName: name, lastName: '', username: name.toLowerCase(), photoUrl: null });
}

test('first free pack creates inventory, history, tokens, and first achievement', () => {
  const db = openDatabase(':memory:');
  const user = newUser(db);

  const result = openDailyPack(db, user.id, { nowMs: T0, randomInt: fixedRoll(0) });

  assert.equal(result.isNew, true);
  assert.equal(result.quantity, 1);
  assert.equal(result.character.rarity, 'rare');
  assert.equal(result.character.id, CHARACTERS_BY_RARITY.rare[0].id);
  assert.ok(result.achievementsUnlocked.some((a) => a.id === 'first_discovery'));

  const history = getHistory(db, user.id);
  assert.equal(history.length, 1);
  assert.equal(history[0].isNew, true);
  assert.equal(history[0].rarity, 'rare');

  const row = db.prepare('SELECT tokens, last_free_day FROM users WHERE id = ?').get(user.id);
  assert.equal(row.last_free_day, utcDay(T0));
  // 5 daily tokens + 10 for First Discovery
  assert.equal(row.tokens, 15);
});

test('a second free pack on the same UTC day is rejected with the next reset time', () => {
  const db = openDatabase(':memory:');
  const user = newUser(db);
  openDailyPack(db, user.id, { nowMs: T0, randomInt: fixedRoll(0) });

  assert.throws(
    () => openDailyPack(db, user.id, { nowMs: T0 + 3_600_000, randomInt: fixedRoll(0) }),
    (error) => {
      assert.ok(error instanceof CooldownError);
      assert.equal(error.status, 409);
      assert.equal(error.nextFreeAt, '2026-11-11T00:00:00.000Z');
      return true;
    },
  );

  // Nothing extra was written by the rejected attempt.
  assert.equal(getHistory(db, user.id).length, 1);
});

test('the free pack resets at UTC midnight', () => {
  const db = openDatabase(':memory:');
  const user = newUser(db);
  openDailyPack(db, user.id, { nowMs: T0, randomInt: fixedRoll(0) });
  const nextDay = Date.UTC(2026, 10, 11, 0, 0, 1);
  const result = openDailyPack(db, user.id, { nowMs: nextDay, randomInt: fixedRoll(0) });
  assert.equal(result.isNew, false);
  assert.equal(getHistory(db, user.id).length, 2);
});

test('a duplicate increments quantity, records a duplicate in history, and keeps the character unlocked', () => {
  const db = openDatabase(':memory:');
  const user = newUser(db);
  openDailyPack(db, user.id, { nowMs: T0, randomInt: fixedRoll(0) });
  const second = openDailyPack(db, user.id, { nowMs: T0 + DAY, randomInt: fixedRoll(0) });

  assert.equal(second.isNew, false);
  assert.equal(second.isDuplicate, true);
  assert.equal(second.quantity, 2);

  const collection = getCollection(db, user.id);
  const entry = collection.characters.find((c) => c.id === second.character.id);
  assert.equal(entry.unlocked, true);
  assert.equal(entry.quantity, 2);

  const history = getHistory(db, user.id);
  assert.equal(history[0].isDuplicate, true);
  assert.equal(history[1].isNew, true);
});

test('collection progress and unique count update with each new character', () => {
  const db = openDatabase(':memory:');
  const user = newUser(db);
  // Use index 0 of each rarity via different rolls, so each pack is a new character.
  openDailyPack(db, user.id, { nowMs: T0, randomInt: fixedRoll(0) });        // rare, shelly
  openDailyPack(db, user.id, { nowMs: T0 + DAY, randomInt: fixedRoll(9999) }); // legendary

  const { progress } = getCollection(db, user.id);
  assert.equal(progress.unique, 2);
  assert.equal(progress.total, CHARACTERS.length);
});

test('Lucky Discovery unlocks on a Legendary and grants its reward once', () => {
  const db = openDatabase(':memory:');
  const user = newUser(db);
  const first = openDailyPack(db, user.id, { nowMs: T0, randomInt: fixedRoll(9999) });
  assert.ok(first.achievementsUnlocked.some((a) => a.id === 'lucky_discovery'));
  const tokensAfterFirst = db.prepare('SELECT tokens FROM users WHERE id = ?').get(user.id).tokens;

  // Further legendary packs must not pay the achievement again.
  openDailyPack(db, user.id, { nowMs: T0 + DAY, randomInt: fixedRoll(9999) });
  const unlockedRows = db.prepare(
    "SELECT COUNT(*) AS n FROM achievements_unlocked WHERE user_id = ? AND achievement_id = 'lucky_discovery'",
  ).get(user.id).n;
  assert.equal(unlockedRows, 1);

  const tokensNow = db.prepare('SELECT tokens FROM users WHERE id = ?').get(user.id).tokens;
  // Day 2 adds only the 5 daily tokens; no second 50-token reward.
  assert.equal(tokensNow - tokensAfterFirst, 5);
});

test('Collector unlocks at 5 unique characters', () => {
  const db = openDatabase(':memory:');
  const user = newUser(db);
  // Give five different characters directly through the inventory rules by opening on five days
  // with five different rarity rolls. Rolls chosen so each lands on a different rarity pool.
  const rolls = [0, 5200, 7900, 9200, 9800];
  let unlocked = [];
  rolls.forEach((roll, i) => {
    const result = openDailyPack(db, user.id, { nowMs: T0 + i * DAY, randomInt: fixedRoll(roll) });
    unlocked = unlocked.concat(result.achievementsUnlocked.map((a) => a.id));
  });
  assert.ok(unlocked.includes('collector'));
  assert.equal(unlocked.filter((id) => id === 'collector').length, 1);
});

test('transactions: a failing step leaves no partial rewards behind', () => {
  const db = openDatabase(':memory:');
  const user = newUser(db);
  // A randomInt that throws mid-operation simulates a crash after the cooldown check.
  assert.throws(() => openDailyPack(db, user.id, { nowMs: T0, randomInt: () => { throw new Error('boom'); } }), /boom/);
  const row = db.prepare('SELECT last_free_day, tokens FROM users WHERE id = ?').get(user.id);
  assert.equal(row.last_free_day, null);
  assert.equal(row.tokens, 0);
  assert.equal(getHistory(db, user.id).length, 0);
});

test('leaderboard reads real database values and excludes users with nothing to rank', () => {
  const db = openDatabase(':memory:');
  const a = newUser(db, 1, 'Alpha');
  const b = newUser(db, 2, 'Beta');
  newUser(db, 3, 'Idle'); // never opened a pack
  openDailyPack(db, a.id, { nowMs: T0, randomInt: fixedRoll(9999) });
  openDailyPack(db, a.id, { nowMs: T0 + DAY, randomInt: fixedRoll(0) });
  openDailyPack(db, b.id, { nowMs: T0, randomInt: fixedRoll(0) });

  const unique = getLeaderboard(db, 'unique');
  assert.deepEqual(unique.map((e) => e.displayName), ['Alpha', 'Beta']);
  assert.equal(unique[0].value, 2);
  assert.equal(unique[0].rank, 1);

  const legendary = getLeaderboard(db, 'legendary');
  assert.equal(legendary.length, 1);
  assert.equal(legendary[0].displayName, 'Alpha');
});

test('leaderboard rejects unknown metrics', () => {
  const db = openDatabase(':memory:');
  assert.throws(() => getLeaderboard(db, 'token_count; DROP TABLE users'), RangeError);
});

test('cosmetics: buying deducts tokens once, equipping requires ownership, and nothing changes RNG', () => {
  const db = openDatabase(':memory:');
  const user = newUser(db);
  // Earn tokens by opening the free pack (15 tokens total on day one).
  openDailyPack(db, user.id, { nowMs: T0, randomInt: fixedRoll(0) });

  // Equipping before owning fails.
  assert.throws(() => equipCosmetic(db, user.id, 'bg_mint_paper'), ConflictError);

  // Mint Paper costs 40 tokens; the player has 15, so the purchase fails.
  assert.throws(() => buyCosmetic(db, user.id, 'bg_mint_paper'), /Not enough tokens/);

  // Give tokens to test the purchase path.
  db.prepare('UPDATE users SET tokens = 100 WHERE id = ?').run(user.id);
  const bought = buyCosmetic(db, user.id, 'bg_mint_paper');
  assert.equal(bought.tokens, 60);
  assert.throws(() => buyCosmetic(db, user.id, 'bg_mint_paper'), /already own/);

  equipCosmetic(db, user.id, 'bg_mint_paper');
  const shop = getShop(db, user.id);
  assert.equal(shop.items.find((i) => i.id === 'bg_mint_paper').equipped, true);
});

test('daily cooldown key uses UTC date, so two timezones cannot double-open', () => {
  assert.equal(utcDay(Date.UTC(2026, 10, 10, 23, 59, 59)), '2026-11-10');
  assert.equal(utcDay(Date.UTC(2026, 10, 11, 0, 0, 0)), '2026-11-11');
});
