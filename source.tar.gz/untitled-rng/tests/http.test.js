import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { openDatabase } from '../server/db.js';
import { createRequestHandler } from '../server/app.js';
import { buildInitData } from './helpers.js';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const BOT_TOKEN = '999:HTTP_TEST_TOKEN';
const T0 = Date.UTC(2026, 10, 10, 12, 0, 0);

let server;
let base;
let db;
const config = {
  botToken: BOT_TOKEN,
  allowUnsignedDevAuth: false,
  initDataMaxAgeSec: 86400,
  publicDir: path.join(ROOT, 'public'),
  sharedDir: path.join(ROOT, 'shared'),
};

before(async () => {
  db = openDatabase(':memory:');
  let fakeNow = T0;
  const handler = createRequestHandler({ db, config, now: () => fakeNow, log: { error() {} } });
  server = http.createServer(handler);
  await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve));
  base = `http://127.0.0.1:${server.address().port}`;
  // Expose a way for tests to move the clock.
  globalThis.__setNow = (ms) => { fakeNow = ms; };
});

after(async () => {
  await new Promise((resolve) => server.close(resolve));
  db.close();
});

async function call(method, route, { auth, body } = {}) {
  const headers = {};
  if (auth) headers.authorization = auth;
  if (body !== undefined) headers['content-type'] = 'application/json';
  const res = await fetch(base + route, { method, headers, body: body !== undefined ? JSON.stringify(body) : undefined });
  const text = await res.text();
  let json = null;
  try { json = JSON.parse(text); } catch { /* not json */ }
  return { status: res.status, json, text };
}

const USER = { id: 555, first_name: 'Http', username: 'http_user' };
// auth_date is the real wall clock (initData freshness is checked against it). Game time is faked separately.
const validAuth = () => `tma ${buildInitData({ botToken: BOT_TOKEN, user: USER })}`;

test('health endpoint works without auth', async () => {
  const res = await call('GET', '/api/health');
  assert.equal(res.status, 200);
  assert.equal(res.json.ok, true);
});

test('protected endpoints reject requests with no auth', async () => {
  for (const route of ['/api/home', '/api/collection', '/api/profile', '/api/history']) {
    const res = await call('GET', route);
    assert.equal(res.status, 401, route);
  }
});

test('protected endpoints reject forged initData', async () => {
  const forged = validAuth().replace(/hash=[0-9a-f]+/, 'hash=' + 'a'.repeat(64));
  const res = await call('GET', '/api/home', { auth: forged });
  assert.equal(res.status, 401);
});

test('dev auth is refused by default even when the header is well-formed', async () => {
  const res = await call('GET', '/api/home', { auth: 'dev 555' });
  assert.equal(res.status, 401);
});

test('a valid signed session opens the free pack through the API, and refresh cannot bypass the cooldown', async () => {
  globalThis.__setNow(T0);
  const first = await call('POST', '/api/packs/open', { auth: validAuth() });
  assert.equal(first.status, 201);
  assert.ok(first.json.character.id);
  assert.ok(['rare', 'super_rare', 'epic', 'mythic', 'legendary'].includes(first.json.character.rarity));

  // Simulates a page refresh: a brand-new request from the same user.
  const second = await call('POST', '/api/packs/open', { auth: validAuth() });
  assert.equal(second.status, 409);
  assert.equal(second.json.code, 'COOLDOWN');
  assert.equal(second.json.nextFreeAt, '2026-11-11T00:00:00.000Z');

  const home = await call('GET', '/api/home', { auth: validAuth() });
  assert.equal(home.status, 200);
  assert.equal(home.json.freeOpening.available, false);
  assert.equal(home.json.user.displayName, 'Http');
});

test('the client cannot choose its reward: the open endpoint ignores any body', async () => {
  globalThis.__setNow(T0 + 86_400_000 * 2);
  const res = await call('POST', '/api/packs/open', { auth: validAuth(), body: { rarity: 'legendary', characterId: 'jae_yong' } });
  assert.equal(res.status, 201);
  // The response was chosen by the server RNG. The body must not have influenced it, so
  // the handler has to return a valid roster character regardless of what was requested.
  assert.ok(['rare', 'super_rare', 'epic', 'mythic', 'legendary'].includes(res.json.character.rarity));
});

test('leaderboard requires auth and rejects unknown metrics', async () => {
  assert.equal((await call('GET', '/api/leaderboard')).status, 401);
  const bad = await call('GET', '/api/leaderboard?metric=tokens', { auth: validAuth() });
  assert.equal(bad.status, 400);
  const good = await call('GET', '/api/leaderboard?metric=total', { auth: validAuth() });
  assert.equal(good.status, 200);
  assert.ok(Array.isArray(good.json.entries));
});

test('unknown API routes return 404 JSON', async () => {
  const res = await call('GET', '/api/nope');
  assert.equal(res.status, 404);
  assert.equal(res.json.error, 'Unknown API route');
});

test('static serving stays inside the public directory', async () => {
  const res = await call('GET', '/..%2F..%2Fpackage.json');
  assert.notEqual(res.status, 200);
  const shared = await call('GET', '/shared/characters.js');
  assert.equal(shared.status, 200);
  assert.match(shared.text, /RARITIES/);
});

test('the app shell is served at /', async () => {
  const res = await call('GET', '/');
  assert.equal(res.status, 200);
  assert.match(res.text, /<title>untitled rng<\/title>/);
});
