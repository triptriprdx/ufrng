import { test } from 'node:test';
import assert from 'node:assert/strict';
import { RARITIES, TOTAL_WEIGHT, CHARACTERS, CHARACTERS_BY_RARITY, CHARACTERS_BY_ID } from '../shared/characters.js';
import { rollRarity, rollCharacter } from '../server/rng.js';

test('rarity weights total exactly 100%', () => {
  const total = RARITIES.reduce((sum, r) => sum + r.weight, 0);
  assert.equal(total, TOTAL_WEIGHT);
  assert.equal(TOTAL_WEIGHT, 10000);
});

test('rarity distribution matches the spec exactly (52/27/13/6/2)', () => {
  const expected = { rare: 5200, super_rare: 2700, epic: 1300, mythic: 600, legendary: 200 };
  for (const r of RARITIES) assert.equal(r.weight, expected[r.id], r.id);
});

test('every one of the 10,000 roll values maps to exactly one rarity', () => {
  const counts = Object.fromEntries(RARITIES.map((r) => [r.id, 0]));
  for (let roll = 0; roll < TOTAL_WEIGHT; roll++) {
    counts[rollRarity(() => roll)] += 1;
  }
  for (const r of RARITIES) {
    assert.equal(counts[r.id], r.weight, `${r.id} should own ${r.weight} roll values`);
  }
});

test('boundary rolls land on the correct rarities', () => {
  assert.equal(rollRarity(() => 0), 'rare');
  assert.equal(rollRarity(() => 5199), 'rare');
  assert.equal(rollRarity(() => 5200), 'super_rare');
  assert.equal(rollRarity(() => 7898), 'super_rare');
  assert.equal(rollRarity(() => 7900), 'epic');
  assert.equal(rollRarity(() => 9199), 'epic');
  assert.equal(rollRarity(() => 9200), 'mythic');
  assert.equal(rollRarity(() => 9799), 'mythic');
  assert.equal(rollRarity(() => 9800), 'legendary');
  assert.equal(rollRarity(() => 9999), 'legendary');
});

test('roster has unique ids and every rarity has at least one character', () => {
  const ids = CHARACTERS.map((c) => c.id);
  assert.equal(new Set(ids).size, ids.length);
  for (const r of RARITIES) assert.ok(CHARACTERS_BY_RARITY[r.id].length > 0, r.id);
});

test('Jae-yong is present and is a separate character from Gene', () => {
  assert.ok(CHARACTERS_BY_ID.jae_yong, 'jae_yong must exist');
  assert.ok(CHARACTERS_BY_ID.gene, 'gene must exist');
  assert.notEqual(CHARACTERS_BY_ID.jae_yong.name, CHARACTERS_BY_ID.gene.name);
  assert.equal(CHARACTERS_BY_ID.jae_yong.mascot, true);
});

test('rollCharacter returns a character of the rolled rarity', () => {
  // Roll 9999 is Legendary; the second call picks from the Legendary pool.
  const sequence = [9999, 1];
  const character = rollCharacter(() => sequence.shift());
  assert.equal(character.rarity, 'legendary');
  assert.equal(character.id, CHARACTERS_BY_RARITY.legendary[1].id);
});

test('every character is reachable: each has a non-empty pool and a valid index', () => {
  for (const r of RARITIES) {
    const pool = CHARACTERS_BY_RARITY[r.id];
    for (let index = 0; index < pool.length; index++) {
      const picked = rollCharacter(
        (max) => (max === TOTAL_WEIGHT ? RARITIES.slice(0, RARITIES.indexOf(r)).reduce((s, x) => s + x.weight, 0) : index),
      );
      assert.equal(picked.rarity, r.id);
    }
  }
});
