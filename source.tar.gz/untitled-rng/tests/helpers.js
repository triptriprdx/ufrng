import crypto from 'node:crypto';

// Builds an initData string exactly the way Telegram does, so tests exercise the
// real validation path rather than a mock.
export function buildInitData({ botToken, user, authDate = Math.floor(Date.now() / 1000), extra = {} }) {
  const fields = {
    auth_date: String(authDate),
    query_id: 'AAHtest',
    user: JSON.stringify(user),
    ...extra,
  };
  const dataCheckString = Object.keys(fields)
    .sort()
    .map((key) => `${key}=${fields[key]}`)
    .join('\n');
  const secretKey = crypto.createHmac('sha256', 'WebAppData').update(botToken).digest();
  const hash = crypto.createHmac('sha256', secretKey).update(dataCheckString).digest('hex');
  const params = new URLSearchParams({ ...fields, hash });
  return params.toString();
}
