// Jae-yong: a small pixel-art mascot asleep behind a counter, head resting on his hand.
// Drawn on a 32x24 grid. Two frames cycle at 2 FPS to suggest slow breathing: on frame B
// the upper body rises by one pixel. Jae-yong is a separate character from Gene.

const C = {
  wall: '#ECE6DA',
  hair: '#3A3536',
  skin: '#F2C9A0',
  skinShade: '#E0AE84',
  shirt: '#A9C2DE',
  shirtShade: '#8FAED4',
  counter: '#D9C4A5',
  counterEdge: '#B39A78',
  ink: '#292A2E',
  cheek: '#F4B9A0',
  zzz: '#969189',
};

// [x, y, w, h, colourKey]
const WALL = [[0, 0, 32, 24, 'wall']];
const CHEST = [[9, 13, 14, 4, 'shirt'], [9, 13, 1, 4, 'shirtShade'], [22, 13, 1, 4, 'shirtShade']];
const UPPER = [
  // hair
  [9, 1, 14, 2, 'hair'],
  [8, 2, 1, 4, 'hair'],
  [23, 2, 1, 4, 'hair'],
  [9, 3, 4, 1, 'hair'],
  // face
  [9, 3, 14, 7, 'skin'],
  [9, 9, 14, 1, 'skinShade'],
  // closed eyes
  [11, 6, 3, 1, 'ink'],
  [18, 6, 3, 1, 'ink'],
  // cheeks
  [10, 8, 2, 1, 'cheek'],
  [20, 8, 2, 1, 'cheek'],
  // neck
  [14, 10, 4, 3, 'skin'],
  // hand supporting the head, resting on the counter
  [7, 10, 9, 3, 'skin'],
  [7, 10, 1, 2, 'skinShade'],
];
const COUNTER = [
  [0, 17, 32, 7, 'counter'],
  [0, 17, 32, 1, 'counterEdge'],
];
// Forearm resting on the counter top, drawn after the counter so it sits on the surface.
const FOREARM = [[3, 15, 8, 2, 'skin'], [3, 15, 8, 1, 'skinShade']];
const ZZZ = [[25, 0, 3, 1, 'zzz'], [26, 1, 1, 1, 'zzz'], [25, 2, 3, 1, 'zzz']];

function rects(list, colours) {
  return list
    .map(([x, y, w, h, key]) => `<rect x="${x}" y="${y}" width="${w}" height="${h}" fill="${colours[key]}"/>`)
    .join('');
}

function frameSvg(riseUpper) {
  const upperDy = riseUpper ? -1 : 0;
  const chestDy = riseUpper ? -1 : 0;
  return `
    <g>${rects(WALL, C)}</g>
    <g transform="translate(0 ${chestDy})">${rects(CHEST, C)}</g>
    <g transform="translate(0 ${upperDy})">${rects(UPPER, C)}</g>
    <g>${rects(FOREARM, C)}</g>
    <g>${rects(COUNTER, C)}</g>
    <g>${rects(ZZZ, C)}</g>`;
}

export function jaeYongSvg(frame = 0) {
  return `<svg viewBox="0 0 32 24" role="img" aria-label="Jae-yong asleep behind the counter" preserveAspectRatio="xMidYMax meet" shape-rendering="crispEdges">${frameSvg(frame === 1)}</svg>`;
}

// Mounts the sprite into `container` and starts the 2 FPS loop. Returns a stop function.
export function mountJaeYong(container) {
  container.innerHTML = jaeYongSvg(0);
  let frame = 0;
  const timer = setInterval(() => {
    frame = 1 - frame;
    if (!container.isConnected) return;
    container.innerHTML = jaeYongSvg(frame);
  }, 500);
  return () => clearInterval(timer);
}
