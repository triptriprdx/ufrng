// Original, deterministic placeholder portraits. Each character gets a symmetric 5x5
// pixel tile derived from its id, so the same character always looks the same.
// These are placeholders until official artwork is licensed or drawn.

import { initials } from '../dom.js';

function hash(text) {
  let h = 2166136261;
  for (let i = 0; i < text.length; i++) {
    h ^= text.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

const INK = '#292A2E';

export function placeholderSvg(character) {
  const seed = hash(character.id);
  const cells = [];
  for (let y = 0; y < 5; y++) {
    for (let x = 0; x < 3; x++) {
      const bit = (seed >>> (y * 3 + x)) & 1;
      if (bit) {
        cells.push([x, y]);
        if (x !== 2) cells.push([4 - x, y]); // mirror across the centre column
      }
    }
  }
  const rects = cells
    .map(([x, y]) => `<rect x="${x}" y="${y}" width="1" height="1" fill="${INK}"/>`)
    .join('');
  return `<svg viewBox="0 0 5 5" aria-hidden="true" preserveAspectRatio="xMidYMid meet">${rects}</svg>`;
}

// Portrait tile: rarity colour background, pixel tile, and the character's initials
// as a small label. Used for the collection, reveal screen and history.
export function portraitHtml(character, { size = '' } = {}) {
  const label = initials(character.name);
  return `
    <div class="portrait rarity-${character.rarity} ${size}" role="img" aria-label="${character.name} placeholder portrait">
      <div style="position:relative;width:100%;height:100%;display:grid;place-items:center">
        <div style="width:62%;height:62%;opacity:0.18">${placeholderSvg(character)}</div>
        <span style="position:absolute;font-weight:800;font-size:14px;letter-spacing:0.02em;color:${INK}">${label}</span>
      </div>
    </div>`;
}

export function mysteryHtml(size = '') {
  return `
    <div class="portrait mystery ${size}" role="img" aria-label="Undiscovered character">
      <span style="font-size:28px;font-weight:800;color:#969189">?</span>
    </div>`;
}
