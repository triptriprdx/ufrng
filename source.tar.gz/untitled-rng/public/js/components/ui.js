import { esc, RARITY_NAMES } from '../dom.js';
import { portraitHtml } from './portrait.js';
import { haptic } from '../telegram.js';
import { ACHIEVEMENTS_BY_ID } from '/shared/achievements.js';

// ---------- Toasts (small notifications) ----------
export function toast(message, kind = '') {
  const root = document.getElementById('toast-root');
  if (!root) return;
  const el = document.createElement('div');
  el.className = `toast ${kind}`.trim();
  el.textContent = message;
  root.appendChild(el);
  setTimeout(() => el.remove(), 3200);
}

// ---------- Tab bar (five main sections) ----------
const TABS = [
  { id: 'home', label: 'Home', href: '#/home', icon: '<path d="M4 11l8-6 8 6v8a1 1 0 0 1-1 1h-4v-6h-6v6H5a1 1 0 0 1-1-1z" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"/>' },
  { id: 'collection', label: 'Collection', href: '#/collection', icon: '<rect x="4" y="4" width="6.5" height="6.5" rx="1" fill="none" stroke="currentColor" stroke-width="1.8"/><rect x="13.5" y="4" width="6.5" height="6.5" rx="1" fill="none" stroke="currentColor" stroke-width="1.8"/><rect x="4" y="13.5" width="6.5" height="6.5" rx="1" fill="none" stroke="currentColor" stroke-width="1.8"/><rect x="13.5" y="13.5" width="6.5" height="6.5" rx="1" fill="none" stroke="currentColor" stroke-width="1.8"/>' },
  { id: 'history', label: 'History', href: '#/history', icon: '<circle cx="12" cy="12" r="8" fill="none" stroke="currentColor" stroke-width="1.8"/><path d="M12 8v4l3 2" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/>' },
  { id: 'leaderboard', label: 'Ranks', href: '#/leaderboard', icon: '<path d="M6 19V11M12 19V5M18 19v-6" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"/>' },
  { id: 'profile', label: 'Profile', href: '#/profile', icon: '<circle cx="12" cy="9" r="3.6" fill="none" stroke="currentColor" stroke-width="1.8"/><path d="M5 20c1.4-3.4 4-5 7-5s5.6 1.6 7 5" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/>' },
];

export function renderTabbar(activeId) {
  const nav = document.getElementById('tabbar');
  if (!nav) return;
  nav.hidden = false;
  nav.innerHTML = TABS.map((t) => `
    <a href="${t.href}" class="${t.id === activeId ? 'active' : ''}" ${t.id === activeId ? 'aria-current="page"' : ''}>
      <svg viewBox="0 0 24 24" aria-hidden="true">${t.icon}</svg>
      <span>${t.label}</span>
    </a>`).join('');
}

export function hideTabbar() {
  const nav = document.getElementById('tabbar');
  if (nav) nav.hidden = true;
}

// ---------- Empty / error / loading states ----------
export function loadingHtml(text = 'Loading…') {
  return `<div class="boot"><p class="muted">${esc(text)}</p></div>`;
}

export function errorHtml(message, retryId = 'retry') {
  return `
    <div class="notice error" role="alert">
      <p style="margin:0 0 10px">${esc(message)}</p>
      <button id="${esc(retryId)}" class="btn-ghost">Try again</button>
    </div>`;
}

// ---------- Reveal overlay (pack result) ----------
export function showReveal(result, { onClose } = {}) {
  const root = document.getElementById('overlay-root');
  if (!root) return;
  const { character, isNew, quantity } = result;
  const tag = isNew
    ? '<span class="tag tag-new">New discovery</span>'
    : `<span class="tag tag-dup">Duplicate · now ×${quantity}</span>`;

  root.innerHTML = `
    <div class="overlay" role="dialog" aria-modal="true" aria-labelledby="reveal-title">
      <div class="reveal rarity-${esc(character.rarity)}">
        ${portraitHtml(character)}
        <h2 id="reveal-title">${esc(character.name)}</h2>
        <div class="rarity-label">${esc(RARITY_NAMES[character.rarity] ?? character.rarity)}</div>
        ${tag}
        <div class="btn-row">
          <button id="reveal-close" class="btn-mint btn-block">Continue</button>
        </div>
      </div>
    </div>`;

  const close = () => {
    root.innerHTML = '';
    onClose?.();
  };
  document.getElementById('reveal-close').addEventListener('click', close);
  document.querySelector('.overlay')?.addEventListener('click', (event) => {
    if (event.target.classList.contains('overlay')) close();
  });
  haptic(character.rarity === 'legendary' || character.rarity === 'mythic' ? 'success' : 'light');
}

export function announceAchievements(achievements) {
  for (const unlocked of achievements) {
    const def = ACHIEVEMENTS_BY_ID[unlocked.id];
    const icon = def?.icon ?? '◆';
    toast(`${icon} Achievement: ${unlocked.name} · +${unlocked.reward} tokens`, 'achievement');
  }
  if (achievements.length) haptic('success');
}
