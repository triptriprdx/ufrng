import { initTelegram, isInTelegram, getDevUserId } from './telegram.js';
import { registerRoute, startRouter } from './router.js';
import { renderHome } from './views/home.js';
import { renderCollection, renderCharacterDetail } from './views/collection.js';
import { renderHistory } from './views/history.js';
import { renderLeaderboard } from './views/leaderboard.js';
import { renderProfile } from './views/profile.js';
import { renderShop } from './views/shop.js';
import { hideTabbar } from './components/ui.js';

initTelegram();

registerRoute(/^\/home$/, { tab: 'home', render: renderHome });
registerRoute(/^\/collection$/, { tab: 'collection', render: renderCollection });
registerRoute(/^\/character\/(?<id>[a-z0-9_]+)$/, { tab: 'collection', render: renderCharacterDetail });
registerRoute(/^\/history$/, { tab: 'history', render: renderHistory });
registerRoute(/^\/leaderboard$/, { tab: 'leaderboard', render: renderLeaderboard });
registerRoute(/^\/profile$/, { tab: 'profile', render: renderProfile });
registerRoute(/^\/shop$/, { tab: 'profile', render: renderShop });

// Outside Telegram, the app only works in development mode (?dev=<telegramId>) and when
// the server has ALLOW_UNSIGNED_DEV_AUTH=true. Otherwise explain how to open it.
if (!isInTelegram && !getDevUserId()) {
  hideTabbar();
  document.getElementById('app').innerHTML = `
    <header class="topbar"><a class="logo" href="#/home"><svg viewBox="0 0 8 8" aria-hidden="true"><rect width="8" height="8" rx="1.5" fill="#CDEBDD"/><rect x="2" y="2" width="4" height="4" fill="#292A2E"/></svg><span>untitled rng</span></a></header>
    <section class="card stack" style="margin-top:24px">
      <h1 class="page-title" style="margin:0">Open it in Telegram</h1>
      <p class="lead" style="margin:0">untitled rng is a Telegram Mini App for the untitled flood community. Open it from the bot’s button to play.</p>
    </section>`;
} else {
  startRouter();
}
