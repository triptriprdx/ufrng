import { setBackButton } from './telegram.js';
import { renderTabbar, hideTabbar } from './components/ui.js';

// Hash-based router so Telegram's BackButton and the browser history both work.
// Each route returns an optional cleanup function (e.g. to stop the mascot animation).

const routes = [];
let currentCleanup = null;
let renderToken = 0;

export function registerRoute(pattern, { tab = null, render, showBack = true }) {
  routes.push({ pattern, tab, render, showBack });
}

export function navigate(path) {
  if (location.hash === `#${path}`) {
    handle();
  } else {
    location.hash = path;
  }
}

function parse(hash) {
  const path = (hash.replace(/^#/, '') || '/home').split('?')[0];
  for (const route of routes) {
    const match = route.pattern.exec(path);
    if (match) return { route, params: match.groups ?? {} };
  }
  return null;
}

async function handle() {
  const token = ++renderToken;
  const app = document.getElementById('app');
  const found = parse(location.hash);

  if (currentCleanup) {
    try { currentCleanup(); } catch { /* ignore cleanup errors */ }
    currentCleanup = null;
  }

  if (!found) {
    navigate('/home');
    return;
  }

  const { route, params } = found;
  if (route.tab) renderTabbar(route.tab); else hideTabbar();

  const isHome = route.tab === 'home';
  setBackButton(!isHome, () => {
    if (history.length > 1) history.back();
    else navigate('/home');
  });

  window.scrollTo(0, 0);
  const cleanup = await route.render(app, params, () => token === renderToken);
  if (token !== renderToken) {
    cleanup?.();
    return;
  }
  currentCleanup = typeof cleanup === 'function' ? cleanup : null;
}

export function startRouter() {
  window.addEventListener('hashchange', handle);
  handle();
}
