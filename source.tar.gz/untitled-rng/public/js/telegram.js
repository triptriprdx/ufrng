// Telegram Mini App integration. Everything here is optional: outside Telegram the
// app still runs in a browser (for development), but identity then comes from the
// `?dev=` parameter, which the server only accepts when ALLOW_UNSIGNED_DEV_AUTH=true.

const tg = window.Telegram?.WebApp ?? null;

let backHandler = null;

export const telegram = tg;
export const isInTelegram = Boolean(tg && tg.initData);

export function initTelegram() {
  if (!tg) return;
  try {
    tg.ready();
    tg.expand();
    tg.setHeaderColor?.('#F6F3EE');
    tg.setBackgroundColor?.('#F6F3EE');
    tg.enableClosingConfirmation?.(false);
  } catch (error) {
    console.warn('Telegram WebApp setup failed', error);
  }
}

export function getInitData() {
  return tg?.initData ?? '';
}

export function getTelegramUser() {
  return tg?.initDataUnsafe?.user ?? null;
}

export function getDevUserId() {
  const raw = new URLSearchParams(location.search).get('dev');
  return raw && /^\d+$/.test(raw) ? raw : null;
}

// Shows Telegram's native BackButton. The handler replaces any previous one.
export function setBackButton(visible, onBack) {
  const button = tg?.BackButton;
  if (!button) return;
  if (backHandler) {
    button.offClick(backHandler);
    backHandler = null;
  }
  if (visible && onBack) {
    backHandler = onBack;
    button.onClick(backHandler);
    button.show();
  } else {
    button.hide();
  }
}

export function haptic(kind = 'light') {
  try {
    if (!tg?.HapticFeedback) return;
    if (kind === 'success' || kind === 'error' || kind === 'warning') {
      tg.HapticFeedback.notificationOccurred(kind);
    } else {
      tg.HapticFeedback.impactOccurred(kind);
    }
  } catch {
    // Haptics are non-essential.
  }
}
