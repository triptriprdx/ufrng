import { getInitData, getDevUserId } from './telegram.js';

export class ApiError extends Error {
  constructor(status, message, body = {}) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
    this.body = body;
  }
}

function authorizationHeader() {
  const initData = getInitData();
  if (initData) return `tma ${initData}`;
  const devId = getDevUserId();
  if (devId) return `dev ${devId}`;
  return null;
}

// Single entry point for all server calls. Identity is sent as initData; the
// server validates its signature and never trusts a user id from the body.
export async function api(path, { method = 'GET', body } = {}) {
  const headers = { Accept: 'application/json' };
  const auth = authorizationHeader();
  if (auth) headers.Authorization = auth;
  if (body !== undefined) headers['Content-Type'] = 'application/json';

  let response;
  try {
    response = await fetch(path, {
      method,
      headers,
      body: body !== undefined ? JSON.stringify(body) : undefined,
      cache: 'no-store',
    });
  } catch {
    throw new ApiError(0, 'Network problem. Check your connection and try again.');
  }

  let data = {};
  try {
    data = await response.json();
  } catch {
    data = {};
  }

  if (!response.ok) {
    const message = data.error || `Request failed (${response.status})`;
    throw new ApiError(response.status, message, data);
  }
  return data;
}
