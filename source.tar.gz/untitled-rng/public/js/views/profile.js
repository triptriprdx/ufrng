import { api, ApiError } from '../api.js';
import { esc, initials } from '../dom.js';
import { getTelegramUser } from '../telegram.js';
import { loadingHtml, errorHtml, renderTabbar } from '../components/ui.js';
import { COSMETICS_BY_ID, COSMETIC_SLOTS } from '/shared/cosmetics.js';

// Maps an equipped cosmetic to a CSS class (see styles.css). Cosmetics are visual only.
function cosmeticClass(itemId, prefix) {
  if (!itemId) return '';
  return `${prefix}-${itemId.replace(/^[a-z]+_/, '')}`;
}

export async function renderProfile(app, _params, isCurrent) {
  renderTabbar('profile');
  app.innerHTML = loadingHtml('Loading profile…');

  let data;
  try {
    data = await api('/api/profile');
  } catch (error) {
    if (!isCurrent()) return;
    app.innerHTML = `<h1 class="page-title">Profile</h1>${errorHtml(error instanceof ApiError ? error.message : 'Could not load your profile.')}`;
    document.getElementById('retry')?.addEventListener('click', () => renderProfile(app, _params, isCurrent));
    return;
  }
  if (!isCurrent()) return;

  const { user, stats, achievements, cosmetics } = data;
  const tg = getTelegramUser();
  const photo = user.photoUrl || tg?.photo_url;
  const equipped = cosmetics.equipped;
  const bgItem = equipped.background ? COSMETICS_BY_ID[equipped.background] : null;
  const plateItem = equipped.nameplate ? COSMETICS_BY_ID[equipped.nameplate] : null;
  const frameItem = equipped.frame ? COSMETICS_BY_ID[equipped.frame] : null;
  const themeItem = equipped.theme ? COSMETICS_BY_ID[equipped.theme] : null;

  const avatar = photo
    ? `<img src="${esc(photo)}" alt="" referrerpolicy="no-referrer" />`
    : esc(initials(user.displayName));

  app.innerHTML = `
    <h1 class="page-title">Profile</h1>

    <section class="profile-hero ${cosmeticClass(equipped.background, 'bg')}" aria-label="Your profile">
      <div class="avatar avatar-lg ${cosmeticClass(equipped.frame, 'frame')}" ${frameItem ? '' : ''}>${avatar}</div>
      <div style="min-width:0">
        <div class="nameplate ${cosmeticClass(equipped.nameplate, 'plate')}">${esc(user.displayName)}</div>
        <div class="small muted" style="margin-top:4px">${user.username ? '@' + esc(user.username) : 'No username set in Telegram'}</div>
        <div class="small" style="margin-top:6px">◇ ${user.tokens} tokens</div>
      </div>
    </section>

    <div class="stat-grid" role="list">
      <div class="stat" role="listitem"><div class="num">${stats.totalDiscoveries}</div><div class="label">Discoveries</div></div>
      <div class="stat" role="listitem"><div class="num">${stats.uniqueCharacters}<span class="muted" style="font-size:14px">/${stats.collectionSize}</span></div><div class="label">Unique</div></div>
      <div class="stat" role="listitem"><div class="num">${stats.legendaryCharacters}</div><div class="label">Legendary</div></div>
    </div>

    <h2 class="section-title">Achievements</h2>
    <ul class="ach-list">
      ${achievements.map((a) => `
        <li class="ach ${a.unlocked ? 'unlocked' : 'locked'}">
          <span class="icon" aria-hidden="true">${esc(a.icon)}</span>
          <div class="info">
            <strong>${esc(a.name)}</strong>
            <span class="small muted">${esc(a.description)}</span>
          </div>
          <span class="reward">${a.unlocked ? 'Unlocked' : `+${a.reward}`}</span>
        </li>`).join('')}
    </ul>

    <h2 class="section-title">Cosmetics</h2>
    <section class="card stack">
      <div class="row-between"><span class="muted small">Profile background</span><span>${esc(bgItem?.name ?? 'Default')}</span></div>
      <div class="row-between"><span class="muted small">Avatar frame</span><span>${esc(frameItem?.name ?? 'None')}</span></div>
      <div class="row-between"><span class="muted small">Nameplate</span><span>${esc(plateItem?.name ?? 'Default')}</span></div>
      <div class="row-between"><span class="muted small">Collection theme</span><span>${esc(themeItem?.name ?? 'Default')}</span></div>
      <div class="small muted" style="margin:0">${cosmetics.owned.length} owned · ${Object.keys(COSMETIC_SLOTS).length} slot types</div>
      <a href="#/shop" class="btn-blue" style="display:flex;align-items:center;justify-content:center;min-height:44px;border-radius:10px;border:1px solid #A2BBDB;text-decoration:none;color:var(--text);font-weight:600">Open cosmetic shop</a>
    </section>

    <p class="tiny" style="margin-top:16px">Tokens are for cosmetics only. They have no cash value and never affect pack odds.</p>
  `;
}
