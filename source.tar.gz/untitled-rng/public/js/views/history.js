import { api, ApiError } from '../api.js';
import { esc, formatDateTime, RARITY_NAMES } from '../dom.js';
import { portraitHtml } from '../components/portrait.js';
import { loadingHtml, errorHtml, renderTabbar } from '../components/ui.js';
import { CHARACTERS_BY_ID } from '/shared/characters.js';

export async function renderHistory(app, _params, isCurrent) {
  renderTabbar('history');
  app.innerHTML = loadingHtml('Loading history…');

  let data;
  try {
    data = await api('/api/history?limit=100');
  } catch (error) {
    if (!isCurrent()) return;
    app.innerHTML = `<h1 class="page-title">History</h1>${errorHtml(error instanceof ApiError ? error.message : 'Could not load history.')}`;
    document.getElementById('retry')?.addEventListener('click', () => renderHistory(app, _params, isCurrent));
    return;
  }
  if (!isCurrent()) return;

  const items = data.items;
  app.innerHTML = `
    <h1 class="page-title">History</h1>
    <p class="lead">Your most recent results appear first.</p>
    ${items.length === 0 ? `
      <div class="empty"><strong>No pack openings yet</strong>Your free daily pack is waiting on Home.</div>` : `
      <ul class="history-list">
        ${items.map((item) => {
          const character = CHARACTERS_BY_ID[item.characterId];
          if (!character) return '';
          return `
            <li class="history-item">
              ${portraitHtml(character, { size: 'compact' })}
              <div class="meta">
                <div class="title">${esc(character.name)}</div>
                <div class="when">${esc(RARITY_NAMES[item.rarity] ?? item.rarity)} · ${esc(formatDateTime(item.createdAt))}</div>
              </div>
              <span class="tag ${item.isNew ? 'tag-new' : 'tag-dup'}">${item.isNew ? 'New' : 'Duplicate'}</span>
            </li>`;
        }).join('')}
      </ul>`}
  `;
}
