import { api, ApiError } from '../api.js';
import { esc, initials } from '../dom.js';
import { loadingHtml, errorHtml, renderTabbar } from '../components/ui.js';

const METRICS = [
  { id: 'unique', label: 'Unique', unit: 'characters', help: 'Different characters collected.' },
  { id: 'total', label: 'Discoveries', unit: 'discoveries', help: 'Every pack result, duplicates included.' },
  { id: 'legendary', label: 'Legendary', unit: 'legendary', help: 'Legendary results received.' },
];

let currentMetric = 'unique';

function avatarOf(entry) {
  if (entry.photoUrl) {
    return `<div class="avatar"><img src="${esc(entry.photoUrl)}" alt="" referrerpolicy="no-referrer" /></div>`;
  }
  return `<div class="avatar" aria-hidden="true">${esc(initials(entry.displayName))}</div>`;
}

export async function renderLeaderboard(app, _params, isCurrent) {
  renderTabbar('leaderboard');
  app.innerHTML = `
    <h1 class="page-title">Leaderboard</h1>
    <p class="lead">Real results from this community’s players.</p>
    <div class="segmented" role="group" aria-label="Ranking category">
      ${METRICS.map((m) => `<button data-metric="${m.id}" aria-pressed="${m.id === currentMetric}">${esc(m.label)}</button>`).join('')}
    </div>
    <div id="board" style="margin-top:12px">${loadingHtml('Ranking…')}</div>`;

  app.querySelectorAll('[data-metric]').forEach((btn) => {
    btn.addEventListener('click', () => {
      currentMetric = btn.dataset.metric;
      renderLeaderboard(app, _params, isCurrent);
    });
  });

  const board = document.getElementById('board');
  const metric = METRICS.find((m) => m.id === currentMetric);

  let data;
  try {
    data = await api(`/api/leaderboard?metric=${encodeURIComponent(currentMetric)}`);
  } catch (error) {
    if (!isCurrent()) return;
    board.innerHTML = errorHtml(error instanceof ApiError ? error.message : 'Leaderboard is unavailable right now.', 'retry');
    document.getElementById('retry')?.addEventListener('click', () => renderLeaderboard(app, _params, isCurrent));
    return;
  }
  if (!isCurrent()) return;

  if (data.entries.length === 0) {
    board.innerHTML = `<div class="empty"><strong>No rankings yet</strong>Open a pack to put your name on the board.</div>`;
    return;
  }

  board.innerHTML = `
    <p class="tiny" style="margin:0 0 4px">${esc(metric.help)}</p>
    <ol class="rank-list">
      ${data.entries.map((entry) => `
        <li class="rank-item ${entry.rank === 1 ? 'top-1' : ''}">
          <span class="rank">${entry.rank}</span>
          ${avatarOf(entry)}
          <div class="who">
            <strong>${esc(entry.displayName)}</strong>
            <span class="tiny">${entry.username ? '@' + esc(entry.username) : ''}</span>
          </div>
          <div style="text-align:right">
            <div class="value">${entry.value}</div>
            <div class="tiny">${esc(metric.unit)}</div>
          </div>
        </li>`).join('')}
    </ol>`;
}
