import { api, ApiError } from '../api.js';
import { esc, formatDateTime, RARITY_NAMES } from '../dom.js';
import { portraitHtml, mysteryHtml } from '../components/portrait.js';
import { loadingHtml, errorHtml, renderTabbar } from '../components/ui.js';
import { RARITIES, CHARACTERS_BY_ID } from '/shared/characters.js';

const PREFS_KEY = 'untitled-rng:collection-prefs'; // UI preference only, never game data

const FILTERS = [
  { id: 'all', label: 'All' },
  ...RARITIES.map((r) => ({ id: r.id, label: r.name })),
];

const SORTS = {
  number: 'Number',
  rarity: 'Rarity',
  name: 'Name',
  duplicates: 'Duplicates',
};

function loadPrefs() {
  try {
    const saved = JSON.parse(localStorage.getItem(PREFS_KEY) ?? '{}');
    return {
      filter: FILTERS.some((f) => f.id === saved.filter) ? saved.filter : 'all',
      sort: SORTS[saved.sort] ? saved.sort : 'number',
    };
  } catch {
    return { filter: 'all', sort: 'number' };
  }
}

function savePrefs(prefs) {
  try {
    localStorage.setItem(PREFS_KEY, JSON.stringify(prefs));
  } catch {
    // Storage may be unavailable (private mode). Preferences are optional.
  }
}

const RARITY_ORDER = Object.fromEntries(RARITIES.map((r) => [r.id, r.order]));

function sortCharacters(list, sort) {
  const copy = [...list];
  switch (sort) {
    case 'rarity':
      return copy.sort((a, b) => RARITY_ORDER[b.rarity] - RARITY_ORDER[a.rarity] || a.collectionOrder - b.collectionOrder);
    case 'name':
      return copy.sort((a, b) => a.name.localeCompare(b.name));
    case 'duplicates':
      return copy.sort((a, b) => b.quantity - a.quantity || a.collectionOrder - b.collectionOrder);
    default:
      return copy.sort((a, b) => a.collectionOrder - b.collectionOrder);
  }
}

export async function renderCollection(app, _params, isCurrent) {
  renderTabbar('collection');
  app.innerHTML = loadingHtml('Opening the archive…');

  let data;
  try {
    data = await api('/api/collection');
  } catch (error) {
    if (!isCurrent()) return;
    app.innerHTML = `<h1 class="page-title">Collection</h1>${errorHtml(error instanceof ApiError ? error.message : 'Could not load your collection.')}`;
    document.getElementById('retry')?.addEventListener('click', () => renderCollection(app, _params, isCurrent));
    return;
  }
  if (!isCurrent()) return;

  const prefs = loadPrefs();
  const { characters, progress } = data;

  const draw = () => {
    const visible = sortCharacters(
      characters.filter((c) => prefs.filter === 'all' || c.rarity === prefs.filter),
      prefs.sort,
    );

    app.innerHTML = `
      <h1 class="page-title">Collection</h1>
      <p class="lead">Every discovery stays here. Duplicates are counted.</p>

      <section class="card" aria-label="Collection progress">
        <div class="row-between">
          <strong>${progress.unique} of ${progress.total} discovered</strong>
          <span class="small muted">${progress.percent}%</span>
        </div>
        <div class="progress" role="progressbar" aria-valuemin="0" aria-valuemax="${progress.total}" aria-valuenow="${progress.unique}">
          <span style="width:${progress.percent}%"></span>
        </div>
      </section>

      <div class="filters" role="group" aria-label="Filter by rarity" style="margin-top:14px">
        ${FILTERS.map((f) => `
          <button class="filter-chip" data-filter="${f.id}" aria-pressed="${prefs.filter === f.id}">${esc(f.label)}</button>
        `).join('')}
      </div>

      <div class="sort-row">
        <span class="small muted">${visible.length} shown</span>
        <label class="row small">
          <span class="muted">Sort</span>
          <select id="sort" aria-label="Sort characters">
            ${Object.entries(SORTS).map(([id, label]) => `<option value="${id}" ${prefs.sort === id ? 'selected' : ''}>${esc(label)}</option>`).join('')}
          </select>
        </label>
      </div>

      ${visible.length === 0 ? `
        <div class="empty"><strong>Nothing here yet</strong>Try a different rarity filter.</div>` : `
        <div class="char-grid">
          ${visible.map((c) => `
            <a class="char-card ${c.unlocked ? '' : 'locked'}" href="#/character/${esc(c.id)}" aria-label="${c.unlocked ? esc(c.name) : 'Undiscovered character'}">
              ${c.unlocked ? portraitHtml(CHARACTERS_BY_ID[c.id]) : mysteryHtml()}
              ${c.unlocked && c.quantity > 1 ? `<span class="qty-badge" aria-label="Owned ${c.quantity}">×${c.quantity}</span>` : ''}
              <span class="name">${c.unlocked ? esc(c.name) : '???'}</span>
              <span class="tiny" style="font-size:13px">${esc(RARITY_NAMES[c.rarity])}</span>
            </a>`).join('')}
        </div>`}
    `;

    app.querySelectorAll('[data-filter]').forEach((el) => {
      el.addEventListener('click', () => {
        prefs.filter = el.dataset.filter;
        savePrefs(prefs);
        draw();
      });
    });
    document.getElementById('sort')?.addEventListener('change', (event) => {
      prefs.sort = event.target.value;
      savePrefs(prefs);
      draw();
    });
  };

  draw();
}

export async function renderCharacterDetail(app, params, isCurrent) {
  renderTabbar('collection');
  app.innerHTML = loadingHtml('Loading…');

  let data;
  try {
    data = await api('/api/collection');
  } catch (error) {
    if (!isCurrent()) return;
    app.innerHTML = errorHtml(error instanceof ApiError ? error.message : 'Could not load this character.');
    return;
  }
  if (!isCurrent()) return;

  const entry = data.characters.find((c) => c.id === params.id);
  if (!entry) {
    app.innerHTML = `<a class="back-link" href="#/collection">← Collection</a><div class="empty"><strong>Unknown character</strong>This character is not in the roster.</div>`;
    return;
  }

  const detailFacts = entry.unlocked
    ? `
      <div><span class="muted">Rarity</span><span>${esc(RARITY_NAMES[entry.rarity])}</span></div>
      <div><span class="muted">Copies owned</span><span>${entry.quantity}</span></div>
      <div><span class="muted">First discovered</span><span>${esc(formatDateTime(entry.firstObtainedAt))}</span></div>`
    : `
      <div><span class="muted">Rarity</span><span>${esc(RARITY_NAMES[entry.rarity])}</span></div>
      <div><span class="muted">Status</span><span>Not discovered yet</span></div>`;

  app.innerHTML = `
    <a class="back-link" href="#/collection">← Collection</a>
    <section class="card detail">
      ${entry.unlocked ? portraitHtml(CHARACTERS_BY_ID[entry.id]) : mysteryHtml()}
      <h1>${entry.unlocked ? esc(entry.name) : '???'}</h1>
      <p class="small muted" style="margin:0">${esc(entry.unlocked ? entry.description ?? 'Lore entry coming soon.' : 'Open packs to discover this character.')}</p>
      <div class="facts">${detailFacts}</div>
    </section>`;
}
