import { api, ApiError } from '../api.js';
import { esc } from '../dom.js';
import { toast, loadingHtml, errorHtml } from '../components/ui.js';
import { renderTabbar } from '../components/ui.js';
import { haptic } from '../telegram.js';

export async function renderShop(app, _params, isCurrent) {
  renderTabbar('profile');
  app.innerHTML = loadingHtml('Opening the shop…');

  let data;
  try {
    data = await api('/api/shop');
  } catch (error) {
    if (!isCurrent()) return;
    app.innerHTML = `<h1 class="page-title">Shop</h1>${errorHtml(error instanceof ApiError ? error.message : 'Could not load the shop.')}`;
    document.getElementById('retry')?.addEventListener('click', () => renderShop(app, _params, isCurrent));
    return;
  }
  if (!isCurrent()) return;

  const draw = (state) => {
    const groups = Object.entries(state.slots).map(([slot, label]) => ({
      slot,
      label,
      items: state.items.filter((item) => item.slot === slot),
    }));

    app.innerHTML = `
      <a class="back-link" href="#/profile">← Profile</a>
      <div class="row-between">
        <h1 class="page-title" style="margin-bottom:0">Shop</h1>
        <span class="chip"><span aria-hidden="true">◇</span><span id="shop-tokens">${state.tokens}</span><span class="muted">tokens</span></span>
      </div>
      <p class="lead" style="margin-top:8px">Cosmetics only. They never change pack odds.</p>

      ${groups.map((group) => `
        <h2 class="section-title">${esc(group.label)}</h2>
        <div class="shop-group">
          ${group.items.map((item) => {
            const needed = Math.max(0, item.cost - state.tokens);
            let action;
            if (item.equipped) action = `<button disabled>Equipped</button>`;
            else if (item.owned) action = `<button class="btn-mint" data-equip="${esc(item.id)}">Equip</button>`;
            else if (needed > 0) action = `<button disabled>${needed} more</button>`;
            else action = `<button class="btn-lavender" data-buy="${esc(item.id)}">Buy · ${item.cost}</button>`;
            return `
              <div class="shop-item">
                <span class="swatch" style="background:${esc(item.color)}" aria-hidden="true"></span>
                <div class="info">
                  <strong>${esc(item.name)}</strong>
                  <span>${item.owned ? 'Owned' : `${item.cost} tokens`}</span>
                </div>
                ${action}
              </div>`;
          }).join('')}
        </div>`).join('')}
    `;

    app.querySelectorAll('[data-buy]').forEach((btn) => {
      btn.addEventListener('click', async () => {
        btn.disabled = true;
        try {
          await api('/api/shop/buy', { method: 'POST', body: { itemId: btn.dataset.buy } });
          haptic('success');
          toast('Cosmetic unlocked');
          reload();
        } catch (error) {
          toast(error.message, 'error');
          btn.disabled = false;
        }
      });
    });
    app.querySelectorAll('[data-equip]').forEach((btn) => {
      btn.addEventListener('click', async () => {
        btn.disabled = true;
        try {
          await api('/api/shop/equip', { method: 'POST', body: { itemId: btn.dataset.equip } });
          toast('Equipped');
          reload();
        } catch (error) {
          toast(error.message, 'error');
          btn.disabled = false;
        }
      });
    });
  };

  const reload = async () => {
    try {
      const fresh = await api('/api/shop');
      if (isCurrent()) draw(fresh);
    } catch (error) {
      toast(error.message, 'error');
    }
  };

  draw(data);
}
