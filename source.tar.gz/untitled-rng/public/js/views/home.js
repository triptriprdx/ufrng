import { api, ApiError } from '../api.js';
import { esc, formatCountdown, RARITY_NAMES } from '../dom.js';
import { mountJaeYong } from '../components/sprite.js';
import { portraitHtml } from '../components/portrait.js';
import { toast, showReveal, announceAchievements, loadingHtml, errorHtml, renderTabbar } from '../components/ui.js';
import { getTelegramUser, haptic } from '../telegram.js';
import { CHARACTERS_BY_ID } from '/shared/characters.js';

const LOGO_SVG = `<svg viewBox="0 0 8 8" aria-hidden="true"><rect width="8" height="8" rx="1.5" fill="#CDEBDD"/><rect x="2" y="2" width="4" height="4" fill="#292A2E"/></svg>`;

const isHomeActive = () => (location.hash || '#/home') === '#/home';

// Timers from the previous home render. Cleared before every new render so that
// re-rendering (after opening a pack) never stacks duplicate loops.
let homeCleanup = null;

function firstName(displayName) {
  return String(displayName ?? '').split(' ')[0] || 'there';
}

function avatarInitials(user) {
  return String(user.displayName ?? '?').trim().split(/\s+/).slice(0, 2).map((p) => p[0] ?? '').join('').toUpperCase() || '?';
}

function avatarHtml(user) {
  const tgUser = getTelegramUser();
  const photo = user.photoUrl || tgUser?.photo_url;
  if (photo) return `<div class="avatar"><img src="${esc(photo)}" alt="" referrerpolicy="no-referrer" /></div>`;
  return `<div class="avatar" aria-hidden="true">${esc(avatarInitials(user))}</div>`;
}

export async function renderHome(app) {
  homeCleanup?.();
  homeCleanup = null;
  app.innerHTML = loadingHtml('Opening the counter…');
  renderTabbar('home');

  let data;
  try {
    data = await api('/api/home');
  } catch (error) {
    if (!isHomeActive()) return;
    app.innerHTML = errorHtml(error instanceof ApiError ? error.message : 'Could not load the home screen.');
    document.getElementById('retry')?.addEventListener('click', () => renderHome(app));
    return;
  }
  if (!isHomeActive()) return;

  const { user, freeOpening, progress, recentHistory, achievementsUnlocked, achievementsTotal } = data;
  let stopSprite = null;
  let countdownTimer = null;

  const latest = recentHistory[0] ? {
    entry: recentHistory[0],
    character: CHARACTERS_BY_ID[recentHistory[0].characterId],
  } : null;

  app.innerHTML = `
    <header class="topbar">
      <a class="logo" href="#/home" aria-label="untitled rng home">${LOGO_SVG}<span>untitled rng</span></a>
      <div class="row">
        <span class="chip" title="Virtual tokens. Cosmetics only, no cash value.">
          <span aria-hidden="true">◇</span><span id="token-count">${user.tokens}</span><span class="muted">tokens</span>
        </span>
        <a href="#/profile" aria-label="Your profile" style="text-decoration:none">${avatarHtml(user)}</a>
      </div>
    </header>

    <p class="welcome">Welcome back, <strong>${esc(firstName(user.displayName))}</strong>.</p>

    <div class="stage">
      <div id="mascot"></div>
    </div>
    <p class="tiny" style="margin:6px 4px 0">Jae-yong · night shift</p>

    <div class="pack-area">
      <button id="open-pack" class="btn-mint pack-btn" ${freeOpening.available ? '' : 'disabled'}>
        ${freeOpening.available ? 'Open today’s free pack' : 'Free pack already opened today'}
      </button>
      <div class="status-line">
        <span>Daily free pack</span>
        <strong id="free-status">${freeOpening.available ? 'Available' : ''}</strong>
      </div>
      <div id="countdown-line" class="tiny" style="margin-top:6px;${freeOpening.available ? 'display:none' : ''}">
        Next free pack in <span id="countdown" style="font-variant-numeric:tabular-nums">--:--:--</span>
      </div>
    </div>

    <section class="card" style="margin-top:16px">
      <div class="row-between">
        <strong>Collection</strong>
        <span class="small muted">${progress.unique} / ${progress.total}</span>
      </div>
      <div class="progress" role="progressbar" aria-valuemin="0" aria-valuemax="${progress.total}" aria-valuenow="${progress.unique}" aria-label="Collection progress">
        <span style="width:${progress.percent}%"></span>
      </div>
      <div class="quick-nav">
        <a href="#/collection" style="background:var(--lavender);border-color:#C9BBE6">Collection</a>
        <a href="#/history" style="background:var(--peach);border-color:#EDBBA0">History</a>
      </div>
    </section>

    <section class="card" style="margin-top:12px" aria-label="Latest result">
      <div class="row-between">
        <strong class="small">Latest discovery</strong>
        <a class="small" href="#/profile" style="color:var(--muted)">Achievements ${achievementsUnlocked}/${achievementsTotal}</a>
      </div>
      ${latest && latest.character ? `
        <div class="latest">
          ${portraitHtml(latest.character, { size: 'compact' })}
          <div style="min-width:0;flex:1">
            <div style="font-weight:600">${esc(latest.character.name)}</div>
            <div class="small muted">${esc(RARITY_NAMES[latest.character.rarity] ?? '')} · ${latest.entry.isNew ? 'New discovery' : 'Duplicate'}</div>
          </div>
          <a href="#/history" class="small" style="color:var(--muted)">History</a>
        </div>` : `<p class="small muted" style="margin:8px 0 0">No discoveries yet. Your first pack is waiting above.</p>`}
    </section>`;

  stopSprite = mountJaeYong(document.getElementById('mascot'));

  const button = document.getElementById('open-pack');
  button?.addEventListener('click', () => openPack(button));

  if (!freeOpening.available) startCountdown(freeOpening.nextFreeAt);

  function startCountdown(nextFreeAt) {
    const target = Date.parse(nextFreeAt);
    const tick = () => {
      if (!isHomeActive() || !document.getElementById('countdown')) {
        clearInterval(countdownTimer);
        return;
      }
      const left = target - Date.now();
      document.getElementById('countdown').textContent = formatCountdown(left);
      if (left <= 0) {
        clearInterval(countdownTimer);
        renderHome(app); // the server decides whether the pack is available
      }
    };
    tick();
    countdownTimer = setInterval(tick, 1000);
  }

  async function openPack(btn) {
    btn.disabled = true;
    btn.classList.add('is-opening');
    btn.textContent = 'Opening…';
    haptic('medium');
    const startedAt = Date.now();

    try {
      const result = await api('/api/packs/open', { method: 'POST' });
      // Keep the shake going for a moment so the reveal feels earned.
      await new Promise((resolve) => setTimeout(resolve, Math.max(0, 900 - (Date.now() - startedAt))));
      btn.classList.remove('is-opening');
      showReveal(result, {
        onClose: () => {
          announceAchievements(result.achievementsUnlocked);
          if (isHomeActive()) renderHome(app);
        },
      });
    } catch (error) {
      btn.classList.remove('is-opening');
      if (error instanceof ApiError && error.status === 409) {
        toast('Today’s free pack is already open. Come back after the reset.');
        if (isHomeActive()) renderHome(app);
        return;
      }
      toast(error.message || 'Could not open the pack. Try again.', 'error');
      btn.disabled = false;
      btn.textContent = 'Open today’s free pack';
    }
  }

  homeCleanup = () => {
    stopSprite?.();
    clearInterval(countdownTimer);
  };
  return homeCleanup;
}
