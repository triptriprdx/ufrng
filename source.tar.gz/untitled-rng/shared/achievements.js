// Achievement definitions. Evaluated on the server only; the client only displays them.
// `metric` is one of the stats computed in server/achievements.js.
// `reward` is virtual tokens (cosmetic currency only, no monetary value).

export const ACHIEVEMENTS = Object.freeze([
  {
    id: 'first_discovery',
    name: 'First Discovery',
    description: 'Open your first pack.',
    icon: '◇',
    metric: 'openings',
    threshold: 1,
    reward: 10,
  },
  {
    id: 'collector',
    name: 'Collector',
    description: 'Collect 5 different characters.',
    icon: '◈',
    metric: 'unique',
    threshold: 5,
    reward: 20,
  },
  {
    id: 'dedicated',
    name: 'Dedicated',
    description: 'Complete 10 pack openings.',
    icon: '◎',
    metric: 'openings',
    threshold: 10,
    reward: 30,
  },
  {
    id: 'variety',
    name: 'Variety',
    description: 'Collect 10 different characters.',
    icon: '◉',
    metric: 'unique',
    threshold: 10,
    reward: 25,
  },
  {
    id: 'lucky_discovery',
    name: 'Lucky Discovery',
    description: 'Receive a Legendary character.',
    icon: '✦',
    metric: 'legendary',
    threshold: 1,
    reward: 50,
  },
  {
    id: 'full_house',
    name: 'Full House',
    description: 'Complete the whole collection.',
    icon: '❖',
    metric: 'full_house',
    threshold: 1,
    reward: 100,
  },
]);

export const ACHIEVEMENTS_BY_ID = Object.freeze(Object.fromEntries(ACHIEVEMENTS.map((a) => [a.id, a])));
