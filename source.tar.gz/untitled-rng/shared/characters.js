// Shared game data: rarity distribution and character roster.
// Used by the server (RNG, validation) and the client (rendering).
//
// IMPORTANT: the per-character rarity tiers below are PLACEHOLDER assignments for
// this game system. They were not verified against Supercell's official in-game
// rarities. Review them before launch. Descriptions are null until real text is
// written, and the UI shows a "coming soon" note in that case.

// Weights are in basis points (1/100 of a percent) so the total is exact integers.
export const RARITIES = Object.freeze([
  { id: 'rare', name: 'Rare', weight: 5200, order: 0 },
  { id: 'super_rare', name: 'Super Rare', weight: 2700, order: 1 },
  { id: 'epic', name: 'Epic', weight: 1300, order: 2 },
  { id: 'mythic', name: 'Mythic', weight: 600, order: 3 },
  { id: 'legendary', name: 'Legendary', weight: 200, order: 4 },
]);

export const TOTAL_WEIGHT = 10000; // exactly 100%

const weightSum = RARITIES.reduce((sum, r) => sum + r.weight, 0);
if (weightSum !== TOTAL_WEIGHT) {
  throw new Error(`Rarity weights must total ${TOTAL_WEIGHT}, got ${weightSum}`);
}

export const RARITY_BY_ID = Object.freeze(Object.fromEntries(RARITIES.map((r) => [r.id, r])));

// Roster. `id` is a stable slug. Never change an id once players own it.
const ROSTER = [
  { id: 'shelly', name: 'Shelly', rarity: 'rare' },
  { id: 'colt', name: 'Colt', rarity: 'rare' },
  { id: 'bull', name: 'Bull', rarity: 'rare' },
  { id: 'brock', name: 'Brock', rarity: 'rare' },
  { id: 'nita', name: 'Nita', rarity: 'rare' },
  { id: 'dynamike', name: 'Dynamike', rarity: 'rare' },
  { id: 'barley', name: 'Barley', rarity: 'rare' },
  { id: 'jessie', name: 'Jessie', rarity: 'rare' },

  { id: 'spike', name: 'Spike', rarity: 'super_rare' },
  { id: 'crow', name: 'Crow', rarity: 'super_rare' },
  { id: 'leon', name: 'Leon', rarity: 'super_rare' },
  { id: 'sandy', name: 'Sandy', rarity: 'super_rare' },
  { id: 'tara', name: 'Tara', rarity: 'super_rare' },
  { id: 'penny', name: 'Penny', rarity: 'super_rare' },
  { id: 'gene', name: 'Gene', rarity: 'super_rare' },
  { id: 'pam', name: 'Pam', rarity: 'super_rare' },

  { id: 'mortis', name: 'Mortis', rarity: 'epic' },
  { id: 'max', name: 'Max', rarity: 'epic' },
  { id: 'mr_p', name: 'Mr. P', rarity: 'epic' },
  { id: 'gus', name: 'Gus', rarity: 'epic' },
  { id: 'emz', name: 'Emz', rarity: 'epic' },
  { id: 'stu', name: 'Stu', rarity: 'epic' },
  { id: 'edgar', name: 'Edgar', rarity: 'epic' },
  { id: 'frank', name: 'Frank', rarity: 'epic' },

  // Jae-yong is the home-screen mascot. He is NOT Gene (a separate entry above).
  { id: 'jae_yong', name: 'Jae-yong', rarity: 'mythic', mascot: true },
  { id: 'belle', name: 'Belle', rarity: 'mythic' },
  { id: 'lou', name: 'Lou', rarity: 'mythic' },
  { id: 'buzz', name: 'Buzz', rarity: 'mythic' },
  { id: 'byron', name: 'Byron', rarity: 'mythic' },

  { id: 'meg', name: 'Meg', rarity: 'legendary' },
  { id: 'surge', name: 'Surge', rarity: 'legendary' },
];

export const CHARACTERS = Object.freeze(
  ROSTER.map((c, index) => {
    if (!RARITY_BY_ID[c.rarity]) throw new Error(`Unknown rarity for ${c.id}: ${c.rarity}`);
    return Object.freeze({
      id: c.id,
      name: c.name,
      rarity: c.rarity,
      mascot: Boolean(c.mascot),
      description: null,
      collectionOrder: index + 1,
    });
  }),
);

export const CHARACTERS_BY_ID = Object.freeze(Object.fromEntries(CHARACTERS.map((c) => [c.id, c])));

export const CHARACTERS_BY_RARITY = Object.freeze(
  Object.fromEntries(RARITIES.map((r) => [r.id, CHARACTERS.filter((c) => c.rarity === r.id)])),
);

for (const rarity of RARITIES) {
  if (CHARACTERS_BY_RARITY[rarity.id].length === 0) {
    throw new Error(`Rarity ${rarity.id} has no characters; the RNG would be unable to pick one`);
  }
}
