// Cosmetic shop catalogue. Cosmetics are purely visual and never affect RNG odds.
// Prices are in virtual tokens (no monetary value, no cash conversion).

export const COSMETIC_SLOTS = Object.freeze({
  background: 'Profile background',
  frame: 'Avatar frame',
  nameplate: 'Nameplate style',
  theme: 'Collection theme',
});

export const COSMETICS = Object.freeze([
  { id: 'bg_mint_paper', slot: 'background', name: 'Mint Paper', cost: 40, color: '#CFEBDD' },
  { id: 'bg_lavender_dust', slot: 'background', name: 'Lavender Dust', cost: 60, color: '#DCD0F0' },
  { id: 'bg_peach_sand', slot: 'background', name: 'Peach Sand', cost: 80, color: '#F7D5C2' },
  { id: 'frame_dusty_blue', slot: 'frame', name: 'Dusty Blue Frame', cost: 50, color: '#B7CBE6' },
  { id: 'frame_muted_gold', slot: 'frame', name: 'Muted Gold Frame', cost: 90, color: '#EBD98C' },
  { id: 'plate_pixel', slot: 'nameplate', name: 'Pixel Nameplate', cost: 35, color: '#E7E2D8' },
  { id: 'plate_ribbon', slot: 'nameplate', name: 'Ribbon Nameplate', cost: 70, color: '#F1E6D0' },
  { id: 'theme_archive', slot: 'theme', name: 'Archive Theme', cost: 120, color: '#FFFEFA' },
]);

export const COSMETICS_BY_ID = Object.freeze(Object.fromEntries(COSMETICS.map((c) => [c.id, c])));
